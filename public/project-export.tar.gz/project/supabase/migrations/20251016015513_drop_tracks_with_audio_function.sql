/*
  # Drop the get_tracks_with_audio_files function

  Removing the function that filtered tracks by storage files.
*/

DROP FUNCTION IF EXISTS get_tracks_with_audio_files();