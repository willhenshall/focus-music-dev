import { createClient } from 'npm:@supabase/supabase-js@2.57.4';
import { readFileSync, readdirSync, existsSync } from 'node:fs';
import { join, basename } from 'node:path';

const SUPABASE_URL = 'https://eafyytltuwuxuuoevavo.supabase.co';
const SUPABASE_KEY = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImVhZnl5dGx0dXd1eHV1b2V2YXZvIiwicm9sZSI6InNlcnZpY2Vfcm9sZSIsImlhdCI6MTc2MDU0NDgwMywiZXhwIjoyMDc2MTIwODAzfQ.tIu_7VgOJvRb1QU-YHKvT1TbNaxOGZgOt_hdbkUQQ64';
const BUCKET_NAME = 'audio-files';

const supabase = createClient(SUPABASE_URL, SUPABASE_KEY);

async function uploadTrack(audioPath: string, jsonPath: string, trackId: string) {
  const sidecar = JSON.parse(readFileSync(jsonPath, 'utf-8'));
  const metadata = sidecar.metadata;
  const fileContent = readFileSync(audioPath);
  const storagePath = `${trackId}.mp3`;

  console.log(`Uploading ${trackId}...`);

  const { error: uploadError } = await supabase.storage
    .from(BUCKET_NAME)
    .upload(storagePath, fileContent, { contentType: 'audio/mpeg', upsert: true });

  if (uploadError) throw uploadError;

  const { data: urlData } = supabase.storage.from(BUCKET_NAME).getPublicUrl(storagePath);
  const channelNames = metadata.channels ? metadata.channels.split(',').map((c: string) => c.trim()) : [];

  const { data: channel } = await supabase
    .from('audio_channels')
    .select('id')
    .ilike('name', channelNames[0])
    .maybeSingle();

  if (!channel) throw new Error(`Channel not found: ${channelNames[0]}`);

  await supabase.from('audio_tracks').insert({
    channel_id: channel.id,
    title: metadata.track_name || 'Untitled',
    artist: metadata.artist_name || 'Unknown',
    album: metadata.album_name || '',
    duration: Number(metadata.duration) || null,
    tempo: Number(metadata.tempo) || null,
    file_path: storagePath,
    file_url: urlData.publicUrl,
    file_size: Number(metadata.file_length) || null,
    genre: metadata.genre_category || null,
    speed: Number(metadata.speed) || null,
    intensity: Number(metadata.intensity) || null,
    arousal: Number(metadata.arousal) || null,
    valence: Number(metadata.valence) || null,
    brightness: Number(metadata.brightness) || null,
    complexity: Number(metadata.complexity) || null,
    energy_level: metadata.energy || null,
    legacy_track_id: metadata.track_id || null
  });
}

const [audioDir, jsonDir] = Deno.args;

if (!audioDir || !jsonDir) {
  console.error('Usage: deno run --allow-all upload.ts <audio-directory> <json-directory>');
  Deno.exit(1);
}

const audioFiles = readdirSync(audioDir)
  .filter(f => f.endsWith('.mp3'))
  .slice(0, 10);

console.log(`Found ${audioFiles.length} audio files to process`);

for (const file of audioFiles) {
  const trackId = basename(file, '.mp3');
  const jsonPath = join(jsonDir, `${trackId}.json`);
  if (existsSync(jsonPath)) {
    try {
      await uploadTrack(join(audioDir, file), jsonPath, trackId);
      console.log(`✅ ${trackId}`);
    } catch (e) {
      console.log(`❌ ${trackId}: ${e}`);
    }
  } else {
    console.log(`⚠️  ${trackId}: No JSON file found`);
  }
}

console.log('Upload complete!');
