import { createContext, useContext, useState, useEffect, ReactNode, useRef } from 'react';
import { supabase, AudioChannel, AudioTrack } from '../lib/supabase';
import { generatePlaylist, EnergyLevel } from '../lib/playlisterService';
import { useAuth } from './AuthContext';
import { trackPlayStart, trackPlayEnd } from '../lib/analyticsService';
import { HTML5AudioEngine, AudioMetrics } from '../lib/html5AudioEngine';

type ChannelState = {
  isOn: boolean;
  energyLevel: 'low' | 'medium' | 'high';
};

type MusicPlayerContextType = {
  channels: AudioChannel[];
  activeChannel: AudioChannel | null;
  channelStates: Record<string, ChannelState>;
  playlist: AudioTrack[];
  currentTrackIndex: number;
  isPlaying: boolean;
  currentTrack: AudioTrack | undefined;
  isAdminMode: boolean;
  adminPreviewTrack: AudioTrack | null;
  audioEngine: HTML5AudioEngine | null;
  audioMetrics: AudioMetrics | null;
  toggleChannel: (channel: AudioChannel, turnOn: boolean, fromPlayer?: boolean) => Promise<void>;
  setChannelEnergy: (channelId: string, energyLevel: 'low' | 'medium' | 'high') => void;
  loadChannels: () => Promise<void>;
  setAdminPreview: (track: AudioTrack | null, autoPlay?: boolean) => void;
  toggleAdminPlayback: () => void;
  skipTrack: () => void;
  seek: (time: number) => void;
  setVolume: (volume: number) => void;
  getVolume: () => number;
};

const MusicPlayerContext = createContext<MusicPlayerContextType | undefined>(undefined);

export function MusicPlayerProvider({ children }: { children: ReactNode }) {
  const { user } = useAuth();
  const [channels, setChannels] = useState<AudioChannel[]>([]);
  const [activeChannel, setActiveChannel] = useState<AudioChannel | null>(null);
  const [channelStates, setChannelStates] = useState<Record<string, ChannelState>>({});
  const [isAdminMode, setIsAdminMode] = useState(false);
  const [adminPreviewTrack, setAdminPreviewTrack] = useState<AudioTrack | null>(null);
  const [playlist, setPlaylist] = useState<AudioTrack[]>([]);
  const [allTracks, setAllTracks] = useState<AudioTrack[]>([]);
  const [currentTrackIndex, setCurrentTrackIndex] = useState(0);
  const [isPlaying, setIsPlaying] = useState(false);
  const [currentSessionId, setCurrentSessionId] = useState<string | null>(null);
  const [currentPlayEventId, setCurrentPlayEventId] = useState<string | null>(null);
  const [audioEngine, setAudioEngine] = useState<HTML5AudioEngine | null>(null);
  const [audioMetrics, setAudioMetrics] = useState<AudioMetrics | null>(null);
  const playStartTimeRef = useRef<number>(0);
  const isLoadingTrack = useRef<boolean>(false);
  const lastPlaylistGeneration = useRef<{ channelId: string; energyLevel: string; timestamp: number } | null>(null);
  const lastLoadedTrackId = useRef<string | null>(null);
  const shouldAutoPlayRef = useRef<boolean>(false);

  // Initialize Web Audio Engine
  useEffect(() => {
    const initializeApp = async () => {
      await loadChannels();
      await loadTracks();
      if (user) {
        await loadLastChannel();
        await incrementSessionCount();
      }
    };

    initializeApp();

    // Create HTML5 Audio Engine
    const engine = new HTML5AudioEngine();

    // Set up callbacks
    engine.setCallbacks({
      onTrackLoad: (trackId, duration) => {
        console.log(`[HTML5Audio] Track loaded: ${trackId}, duration: ${duration}s`);
      },
      onTrackEnd: () => {
        console.log('[HTML5Audio] Track ended, advancing to next');
        handleTrackEnd();
      },
      onDiagnosticsUpdate: (metrics) => {
        setAudioMetrics(metrics);
      },
    });

    setAudioEngine(engine);

    // Subscribe to channel updates for real-time display_order changes
    const channelSubscription = supabase
      .channel('audio_channels_changes')
      .on(
        'postgres_changes',
        {
          event: 'UPDATE',
          schema: 'public',
          table: 'audio_channels'
        },
        () => {
          loadChannels();
        }
      )
      .subscribe();

    return () => {
      engine.destroy();
      channelSubscription.unsubscribe();
    };
  }, [user]);

  // Control crossfading based on admin mode
  useEffect(() => {
    if (!audioEngine) return;

    // Disable crossfading in admin mode for instant playback
    audioEngine.setCrossfadeEnabled(!isAdminMode);
  }, [audioEngine, isAdminMode]);

  // Generate new playlist when channel or tracks change
  // Note: Energy level changes are handled separately via setChannelEnergy
  useEffect(() => {
    if (activeChannel && allTracks.length > 0 && user) {
      const channelState = channelStates[activeChannel.id];

      // Don't generate playlist if channel isn't turned on yet
      if (!channelState?.isOn) {
        console.log('[useEffect] Skipping playlist generation - channel not active yet');
        return;
      }

      const energyLevel = channelState?.energyLevel || 'medium';
      const key = `${activeChannel.id}-${energyLevel}`;

      // Only generate if we haven't generated for this channel+energy combo in the last 1 second
      const lastGen = lastPlaylistGeneration.current;
      const now = Date.now();
      if (lastGen && lastGen.channelId === activeChannel.id && lastGen.energyLevel === energyLevel && (now - lastGen.timestamp) < 1000) {
        console.log('[useEffect] Skipping duplicate playlist generation');
        return;
      }

      console.log('[useEffect] Generating playlist due to channel/tracks/user change');
      lastPlaylistGeneration.current = { channelId: activeChannel.id, energyLevel, timestamp: now };
      generateNewPlaylist();
    }
  }, [activeChannel, allTracks, user, channelStates]);

  // Load and play track when index changes or admin preview changes
  useEffect(() => {
    if (!audioEngine) return;

    const loadAndPlay = async () => {
      if (isLoadingTrack.current) {
        console.log('[loadAndPlay] Already loading, skipping');
        return;
      }

      const track = isAdminMode ? adminPreviewTrack : playlist[currentTrackIndex];
      const trackId = track?.metadata?.track_id?.toString();

      console.log('[loadAndPlay] Loading track at index', currentTrackIndex, 'of', playlist.length, 'trackId:', trackId);

      if (!trackId) {
        console.log('[loadAndPlay] No track or track_id, skipping');
        return;
      }

      // Skip if we're trying to load the same track that's already loaded
      if (lastLoadedTrackId.current === trackId) {
        console.log('[loadAndPlay] Track', trackId, 'is already loaded, skipping');
        return;
      }

      isLoadingTrack.current = true;
      lastLoadedTrackId.current = trackId;

      try {
        // End previous track analytics
        if (currentPlayEventId && !isAdminMode) {
          const playDuration = (Date.now() - playStartTimeRef.current) / 1000;
          await trackPlayEnd(
            currentPlayEventId,
            playDuration,
            false,
            audioEngine.getCurrentTime()
          );
          setCurrentPlayEventId(null);
        }

        // Load new track
        const audioUrl = `${import.meta.env.VITE_SUPABASE_URL}/storage/v1/object/public/audio-files/${track.metadata.track_id}.mp3`;
        console.log('[HTML5Audio] Loading track:', track.metadata.track_id, 'from URL:', audioUrl);

        await audioEngine.loadTrack(track.metadata.track_id, audioUrl, {
          trackName: track.metadata.track_name,
          artistName: track.metadata.artist_name,
        });

        // Start analytics for non-admin tracks
        if (!isAdminMode && track.metadata.track_id) {
          playStartTimeRef.current = Date.now();
          const eventId = await trackPlayStart(
            track.metadata.track_id,
            track.metadata.duration || 0,
            user?.id,
            activeChannel?.id,
            currentSessionId || undefined
          );
          if (eventId) {
            setCurrentPlayEventId(eventId);
          }
        }

        // Auto-play if should be playing or if autoPlay was requested
        if (isPlaying || shouldAutoPlayRef.current) {
          shouldAutoPlayRef.current = false;
          setIsPlaying(true);
          await audioEngine.play();
        }
      } catch (error) {
        console.error('[HTML5Audio] Error loading track:', error);

        // If track fails to load and we're not in admin mode, skip to next track
        if (!isAdminMode && playlist.length > 0) {
          console.log('[HTML5Audio] Skipping to next track due to load error');
          // Clear the failed track from lastLoadedTrackId so we can try the next one
          lastLoadedTrackId.current = null;

          // Move to next track after a brief delay
          setTimeout(() => {
            if (currentTrackIndex < playlist.length - 1) {
              setCurrentTrackIndex(prev => prev + 1);
            } else {
              setCurrentTrackIndex(0);
            }
          }, 1000);
        }
      } finally {
        isLoadingTrack.current = false;
      }
    };

    loadAndPlay();
  }, [audioEngine, playlist, currentTrackIndex, isAdminMode, adminPreviewTrack]);

  // Handle play/pause state changes independently
  useEffect(() => {
    if (!audioEngine) return;
    if (isLoadingTrack.current) return;

    const currentlyPlaying = audioEngine.isPlaying();
    const hasBuffer = audioEngine.getDuration() > 0;

    if (isPlaying && !currentlyPlaying && hasBuffer) {
      audioEngine.play().catch(err => console.error('[HTML5Audio] Play error:', err));
    } else if (!isPlaying && currentlyPlaying) {
      audioEngine.pause();
    }
  }, [isPlaying, audioEngine]);

  const handleTrackEnd = async () => {
    if (isAdminMode) return;

    // Track analytics handled in the next track load
    if (currentTrackIndex < playlist.length - 1) {
      setCurrentTrackIndex(prev => prev + 1);
    } else {
      setCurrentTrackIndex(0);
    }
  };

  const loadChannels = async () => {
    const { data } = await supabase
      .from('audio_channels')
      .select('*')
      .order('display_order');
    if (data) setChannels(data);
  };

  const loadTracks = async () => {
    console.log('[loadTracks] Loading all tracks from database...');
    const { data, error } = await supabase
      .from('audio_tracks')
      .select('*');

    if (error) {
      console.error('[loadTracks] Error loading tracks:', error);
      return;
    }

    if (data) {
      setAllTracks(data);
    }
  };

  const loadLastChannel = async () => {
    if (!user) return;

    const { data: userPreference } = await supabase
      .from('user_preferences')
      .select('last_channel_id, channel_energy_levels, last_energy_level')
      .eq('user_id', user.id)
      .maybeSingle();

    if (userPreference?.last_channel_id) {
      const { data: channel } = await supabase
        .from('audio_channels')
        .select('*')
        .eq('id', userPreference.last_channel_id)
        .single();

      if (channel) {
        const savedEnergyLevels = userPreference.channel_energy_levels || {};
        const channelEnergy = savedEnergyLevels[channel.id] || userPreference.last_energy_level || 'medium';

        setActiveChannel(channel);
        setChannelStates(prev => ({
          ...prev,
          [channel.id]: {
            isOn: false,
            energyLevel: channelEnergy as 'low' | 'medium' | 'high'
          }
        }));
        return;
      }
    }

    const { data: firstChannel } = await supabase
      .from('audio_channels')
      .select('*')
      .order('channel_number')
      .limit(1)
      .maybeSingle();

    if (firstChannel) {
      setActiveChannel(firstChannel);
      setChannelStates(prev => ({
        ...prev,
        [firstChannel.id]: {
          isOn: false,
          energyLevel: 'medium'
        }
      }));

      await supabase
        .from('user_preferences')
        .upsert(
          {
            user_id: user.id,
            last_channel_id: firstChannel.id
          },
          {
            onConflict: 'user_id'
          }
        );
    }
  };

  const incrementSessionCount = async () => {
    if (!user) return;

    const { data: currentPrefs } = await supabase
      .from('user_preferences')
      .select('session_count')
      .eq('user_id', user.id)
      .maybeSingle();

    const currentCount = currentPrefs?.session_count || 0;

    await supabase
      .from('user_preferences')
      .upsert(
        {
          user_id: user.id,
          session_count: currentCount + 1
        },
        {
          onConflict: 'user_id'
        }
      );
  };

  const saveLastChannel = async (channelId: string) => {
    if (!user) return;

    await supabase
      .from('user_preferences')
      .upsert(
        {
          user_id: user.id,
          last_channel_id: channelId
        },
        {
          onConflict: 'user_id'
        }
      );
  };

  const generateNewPlaylist = async (overrideEnergyLevel?: 'low' | 'medium' | 'high') => {
    if (!activeChannel || !user) return;

    const channelState = channelStates[activeChannel.id];
    const energyLevel = overrideEnergyLevel || channelState?.energyLevel || 'medium';

    console.log('[generateNewPlaylist] Generating for channel:', activeChannel.channel_name, 'energy:', energyLevel, 'override:', overrideEnergyLevel);

    // Update the ref to track this generation
    lastPlaylistGeneration.current = { channelId: activeChannel.id, energyLevel, timestamp: Date.now() };

    const playlistResponse = await generatePlaylist({
      channelId: activeChannel.id,
      energyLevel: energyLevel as EnergyLevel,
      userId: user.id,
      strategy: 'weighted',
    });

    console.log('[generateNewPlaylist] Got', playlistResponse.trackIds.length, 'track IDs');

    // Fetch the specific tracks from the database
    const { data: playlistTracks, error } = await supabase
      .from('audio_tracks')
      .select('*')
      .in('metadata->>track_id', playlistResponse.trackIds)
      .is('deleted_at', null);

    if (error || !playlistTracks || playlistTracks.length === 0) {
      console.error('[Playlist] Error loading tracks:', error);
      return;
    }

    console.log('[generateNewPlaylist] Loaded', playlistTracks.length, 'tracks from DB');

    // Reorder tracks to match the order of trackIds
    const orderedTracks = playlistResponse.trackIds
      .map(trackId => playlistTracks.find(t => t.metadata?.track_id === trackId))
      .filter((t): t is AudioTrack => t !== undefined);

    console.log('[generateNewPlaylist] Setting playlist with', orderedTracks.length, 'ordered tracks');
    setPlaylist(orderedTracks);
    setCurrentTrackIndex(0);

    await supabase.from('playlists').insert({
      user_id: user.id,
      channel_id: activeChannel.id,
      energy_level: energyLevel,
      track_sequence: playlistResponse.trackIds,
    });
  };

  const toggleChannel = async (channel: AudioChannel, turnOn: boolean, fromPlayer: boolean = false) => {
    console.log('⏰ toggleChannel called:', { channelId: channel.id, turnOn, fromPlayer, currentIsPlaying: isPlaying });
    if (turnOn) {
      // No special context resume needed for HTML5 audio

      const newStates: Record<string, ChannelState> = {};
      Object.keys(channelStates).forEach(key => {
        newStates[key] = { ...channelStates[key], isOn: false };
      });

      newStates[channel.id] = {
        isOn: true,
        energyLevel: channelStates[channel.id]?.energyLevel || 'medium'
      };

      setChannelStates(newStates);
      setActiveChannel(channel);
      setIsPlaying(true);

      if (user) {
        await saveLastChannel(channel.id);

        const { data } = await supabase
          .from('listening_sessions')
          .insert({
            user_id: user.id,
            channel_id: channel.id,
            energy_level: newStates[channel.id].energyLevel,
            started_at: new Date().toISOString(),
          })
          .select()
          .single();

        if (data) setCurrentSessionId(data.id);
      }
    } else {
      // Turn off the channel
      console.log('⏰ Turning off channel:', channel.id, 'activeChannel:', activeChannel?.id);
      if (activeChannel?.id === channel.id) {
        console.log('⏰ Setting isPlaying to false and pausing audio engine');
        setIsPlaying(false);
        if (audioEngine) {
          // Use pause for smoother UX, but channel is still marked as off
          audioEngine.pause();
        }
      }

      setChannelStates(prev => {
        const newState = {
          ...prev,
          [channel.id]: { ...prev[channel.id], isOn: false }
        };
        console.log('⏰ Updated channel states:', newState);
        return newState;
      });
    }
  };

  const setChannelEnergy = async (channelId: string, energyLevel: 'low' | 'medium' | 'high') => {
    console.log('[setChannelEnergy] Called with:', { channelId, energyLevel });
    const channel = channels.find(c => c.id === channelId);
    if (!channel) return;

    if (user) {
      const { data: userPreference } = await supabase
        .from('user_preferences')
        .select('channel_energy_levels')
        .eq('user_id', user.id)
        .maybeSingle();

      const energyLevels = userPreference?.channel_energy_levels || {};
      energyLevels[channelId] = energyLevel;

      await supabase
        .from('user_preferences')
        .upsert(
          {
            user_id: user.id,
            last_channel_id: channelId,
            channel_energy_levels: energyLevels,
            last_energy_level: energyLevel
          },
          {
            onConflict: 'user_id'
          }
        );
    }

    if (activeChannel?.id !== channelId) {
      console.log('[setChannelEnergy] Switching to different channel');
      // Don't stop audio immediately - let current track play until new track loads
      // The loadAndPlay function will handle the transition

      const newStates: Record<string, ChannelState> = {};
      Object.keys(channelStates).forEach(key => {
        newStates[key] = { ...channelStates[key], isOn: false };
      });

      newStates[channelId] = {
        isOn: true,
        energyLevel
      };

      setChannelStates(newStates);
      setActiveChannel(channel);
      setIsPlaying(true);

      if (user) {
        await saveLastChannel(channelId);

        const { data } = await supabase
          .from('listening_sessions')
          .insert({
            user_id: user.id,
            channel_id: channelId,
            energy_level: energyLevel,
            started_at: new Date().toISOString(),
          })
          .select()
          .single();

        if (data) setCurrentSessionId(data.id);
      }
    } else {
      console.log('[setChannelEnergy] Changing energy level for active channel');

      // Store the current playing state
      const wasPlaying = isPlaying;

      setChannelStates(prev => ({
        ...prev,
        [channelId]: { ...prev[channelId], energyLevel }
      }));

      if (allTracks.length > 0 && user) {
        console.log('[setChannelEnergy] Generating new playlist with energy:', energyLevel);
        // Clear last loaded track so new playlist starts fresh
        lastLoadedTrackId.current = null;

        // If currently playing, ensure the new track will auto-play
        if (wasPlaying) {
          shouldAutoPlayRef.current = true;
        }

        // Pass energy level directly to avoid stale state
        await generateNewPlaylist(energyLevel);
      }
    }
  };

  const setAdminPreview = (track: AudioTrack | null, autoPlay: boolean = false) => {
    if (track) {
      shouldAutoPlayRef.current = autoPlay;
      setIsAdminMode(true);
      setAdminPreviewTrack(track);
      if (!autoPlay) {
        setIsPlaying(false);
        if (audioEngine) {
          audioEngine.stop();
        }
      }
    } else {
      shouldAutoPlayRef.current = false;
      setIsAdminMode(false);
      setAdminPreviewTrack(null);
      setIsPlaying(false);
      if (audioEngine) {
        audioEngine.stop();
      }
    }
  };

  const toggleAdminPlayback = async () => {
    if (!audioEngine || !adminPreviewTrack) return;

    if (isPlaying) {
      // Currently playing, so pause
      audioEngine.pause();
      setIsPlaying(false);
    } else {
      // Currently paused, so play
      try {
        await audioEngine.play();
        setIsPlaying(true);
      } catch (error) {
        console.error('[toggleAdminPlayback] Play error:', error);
      }
    }
  };

  const skipTrack = async () => {
    if (isAdminMode) return;

    if (currentPlayEventId && audioEngine) {
      const playDuration = (Date.now() - playStartTimeRef.current) / 1000;
      await trackPlayEnd(
        currentPlayEventId,
        playDuration,
        true,
        audioEngine.getCurrentTime()
      );
      setCurrentPlayEventId(null);
    }

    if (currentSessionId && currentTrack) {
      supabase
        .from('listening_sessions')
        .select('tracks_skipped')
        .eq('id', currentSessionId)
        .single()
        .then(({ data }) => {
          const skippedTracks = (data?.tracks_skipped as string[]) || [];
          const trackId = currentTrack.metadata?.track_id;
          if (trackId && !skippedTracks.includes(trackId)) {
            supabase
              .from('listening_sessions')
              .update({
                tracks_skipped: [...skippedTracks, trackId]
              })
              .eq('id', currentSessionId)
              .then(() => {});
          }
        });
    }

    // Clear the last loaded track so the next track will load
    lastLoadedTrackId.current = null;

    if (currentTrackIndex < playlist.length - 1) {
      setCurrentTrackIndex(prev => prev + 1);
    } else {
      setCurrentTrackIndex(0);
    }
  };

  const seek = (time: number) => {
    if (audioEngine) {
      audioEngine.seek(time);
    }
  };

  const setVolume = (volume: number) => {
    if (audioEngine) {
      audioEngine.setVolume(volume);
    }
  };

  const getVolume = (): number => {
    return audioEngine?.getVolume() || 0.7;
  };

  const currentTrack = isAdminMode ? (adminPreviewTrack || undefined) : playlist[currentTrackIndex];

  return (
    <MusicPlayerContext.Provider
      value={{
        channels,
        activeChannel,
        channelStates,
        playlist,
        currentTrackIndex,
        isPlaying,
        currentTrack,
        isAdminMode,
        adminPreviewTrack,
        audioEngine,
        audioMetrics,
        toggleChannel,
        setChannelEnergy,
        loadChannels,
        setAdminPreview,
        toggleAdminPlayback,
        skipTrack,
        seek,
        setVolume,
        getVolume,
      }}
    >
      {children}
    </MusicPlayerContext.Provider>
  );
}

export function useMusicPlayer() {
  const context = useContext(MusicPlayerContext);
  if (context === undefined) {
    throw new Error('useMusicPlayer must be used within a MusicPlayerProvider');
  }
  return context;
}
