import ImageSetsManager from './ImageSetsManager';

export function ChannelImages() {
  return <ImageSetsManager />;
}
