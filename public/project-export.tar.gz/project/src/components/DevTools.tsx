import { useState, useEffect } from 'react';
import { Settings, AlertCircle, Check, Info, Eye, EyeOff } from 'lucide-react';
import { supabase } from '../lib/supabase';
import { useAuth } from '../contexts/AuthContext';

export function DevTools() {
  const { user } = useAuth();
  const [recommendationSessions, setRecommendationSessions] = useState<number>(5);
  const [showSlideshowDebug, setShowSlideshowDebug] = useState(false);
  const [isLoading, setIsLoading] = useState(true);
  const [isSaving, setIsSaving] = useState(false);
  const [saveStatus, setSaveStatus] = useState<string>('');
  const [error, setError] = useState<string>('');
  const [debugToggleLoading, setDebugToggleLoading] = useState(false);

  useEffect(() => {
    loadSettings();
  }, []);

  const loadSettings = async () => {
    setIsLoading(true);
    setError('');

    try {
      const { data, error: fetchError } = await supabase
        .from('system_preferences')
        .select('recommendation_visibility_sessions')
        .eq('id', 1)
        .maybeSingle();

      if (fetchError) throw fetchError;

      if (data) {
        setRecommendationSessions(data.recommendation_visibility_sessions || 5);
      }

      // Load user debug preferences
      if (user?.id) {
        const { data: userPrefs } = await supabase
          .from('user_preferences')
          .select('show_slideshow_debug')
          .eq('user_id', user.id)
          .maybeSingle();

        if (userPrefs) {
          setShowSlideshowDebug(userPrefs.show_slideshow_debug || false);
        }
      }
    } catch (err) {
      console.error('Error loading settings:', err);
      setError('Failed to load settings. Please refresh the page.');
    } finally {
      setIsLoading(false);
    }
  };

  const handleSave = async () => {
    if (!user?.id) return;

    setIsSaving(true);
    setSaveStatus('');
    setError('');

    try {
      const { error: updateError } = await supabase
        .from('system_preferences')
        .update({
          recommendation_visibility_sessions: recommendationSessions,
          updated_at: new Date().toISOString(),
          updated_by: user.id,
        })
        .eq('id', 1);

      if (updateError) throw updateError;

      setSaveStatus('Settings saved successfully!');
      setTimeout(() => setSaveStatus(''), 3000);
    } catch (err) {
      console.error('Error saving settings:', err);
      setError('Failed to save settings. Please try again.');
    } finally {
      setIsSaving(false);
    }
  };

  const toggleSlideshowDebug = async () => {
    if (!user?.id) return;

    setDebugToggleLoading(true);

    try {
      const newValue = !showSlideshowDebug;

      await supabase
        .from('user_preferences')
        .upsert({
          user_id: user.id,
          show_slideshow_debug: newValue,
          updated_at: new Date().toISOString(),
        }, {
          onConflict: 'user_id',
        });

      setShowSlideshowDebug(newValue);
    } catch (err) {
      console.error('Error toggling slideshow debug:', err);
    } finally {
      setDebugToggleLoading(false);
    }
  };

  if (isLoading) {
    return (
      <div className="flex items-center justify-center p-12">
        <div className="inline-block animate-spin rounded-full h-8 w-8 border-4 border-blue-500 border-t-transparent" />
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
        <div className="flex items-start gap-3">
          <Info size={20} className="text-blue-600 flex-shrink-0 mt-0.5" />
          <div className="text-sm text-blue-900">
            <p className="font-semibold mb-1">Developer Tools</p>
            <p className="text-blue-800">
              These settings control application behavior for testing and development purposes. Changes affect all users.
            </p>
          </div>
        </div>
      </div>

      {/* Recommendation Visibility Control */}
      <div className="bg-white rounded-lg shadow-sm border border-slate-200 p-6">
        <div className="flex items-start gap-3 mb-4">
          <Settings size={24} className="text-slate-700 flex-shrink-0" />
          <div className="flex-1">
            <h3 className="text-lg font-semibold text-slate-900 mb-1">
              Personalized Recommendations Visibility
            </h3>
            <p className="text-sm text-slate-600">
              Control how many sessions new users see the highlighted personalized recommendation frame on the Channels page.
            </p>
          </div>
        </div>

        <div className="space-y-4">
          <div>
            <label className="block text-sm font-medium text-slate-700 mb-2">
              Number of Sessions to Show Recommendations
            </label>
            <div className="flex items-center gap-4">
              <input
                type="number"
                min="0"
                max="100"
                value={recommendationSessions}
                onChange={(e) => setRecommendationSessions(parseInt(e.target.value) || 0)}
                className="w-32 px-3 py-2 border border-slate-300 rounded-md focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              />
              <span className="text-sm text-slate-600">
                sessions (0 = never show, 1-100 = show for first N sessions)
              </span>
            </div>
          </div>

          {/* Explanation */}
          <div className="bg-slate-50 rounded-lg p-4 space-y-2">
            <p className="text-sm font-medium text-slate-900">How it works:</p>
            <ul className="text-sm text-slate-600 space-y-1 ml-4 list-disc">
              <li>New users start with a session count of 0</li>
              <li>
                Users will see the blue-framed "Your Personalized Recommendations" section while their session count is less than this value
              </li>
              <li>For example, if set to 2, users will see the frame during sessions 0 and 1 (their first 2 sessions)</li>
              <li>After reaching or exceeding this threshold, the frame disappears but recommendations still appear at the top when sorted by "Recommended"</li>
              <li>Set to 0 to never show the highlighted frame</li>
            </ul>
          </div>

          {/* Current Setting Info */}
          <div className="flex items-center gap-2 text-sm text-slate-600 bg-blue-50 p-3 rounded-md border border-blue-100">
            <AlertCircle size={16} className="text-blue-600 flex-shrink-0" />
            <span>
              Currently set to <strong>{recommendationSessions}</strong> session{recommendationSessions !== 1 ? 's' : ''}
            </span>
          </div>

          {/* Save Button */}
          <button
            onClick={handleSave}
            disabled={isSaving}
            className="w-full bg-blue-600 hover:bg-blue-700 text-white font-semibold py-2 px-4 rounded-md transition-colors disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center gap-2"
          >
            {isSaving ? (
              <>
                <div className="inline-block animate-spin rounded-full h-4 w-4 border-2 border-white border-t-transparent" />
                Saving...
              </>
            ) : (
              <>
                <Check size={18} />
                Save Settings
              </>
            )}
          </button>

          {/* Status Messages */}
          {saveStatus && (
            <div className="text-sm p-3 rounded-md bg-green-50 text-green-700 flex items-center gap-2">
              <Check size={16} />
              {saveStatus}
            </div>
          )}

          {error && (
            <div className="text-sm p-3 rounded-md bg-red-50 text-red-700 flex items-center gap-2">
              <AlertCircle size={16} />
              {error}
            </div>
          )}
        </div>
      </div>

      {/* Slideshow Debug Overlay Toggle */}
      <div className="bg-white rounded-lg shadow-sm border border-slate-200 p-6">
        <div className="flex items-start gap-3 mb-4">
          <Eye size={24} className="text-slate-700 flex-shrink-0" />
          <div className="flex-1">
            <h3 className="text-lg font-semibold text-slate-900 mb-1">
              Slideshow Debug Overlay
            </h3>
            <p className="text-sm text-slate-600">
              Display diagnostic information while viewing the slideshow to debug image transitions, timing, and state.
            </p>
          </div>
        </div>

        <div className="space-y-4">
          {/* Toggle Button */}
          <button
            onClick={toggleSlideshowDebug}
            disabled={debugToggleLoading}
            className={`w-full py-3 px-4 rounded-lg font-semibold transition-all flex items-center justify-center gap-3 ${
              showSlideshowDebug
                ? 'bg-green-600 hover:bg-green-700 text-white'
                : 'bg-slate-200 hover:bg-slate-300 text-slate-700'
            } disabled:opacity-50 disabled:cursor-not-allowed`}
          >
            {debugToggleLoading ? (
              <>
                <div className="inline-block animate-spin rounded-full h-5 w-5 border-2 border-white border-t-transparent" />
                Updating...
              </>
            ) : (
              <>
                {showSlideshowDebug ? (
                  <>
                    <Eye size={20} />
                    Debug Overlay Enabled
                  </>
                ) : (
                  <>
                    <EyeOff size={20} />
                    Debug Overlay Disabled
                  </>
                )}
              </>
            )}
          </button>

          {/* Status Info */}
          <div className={`flex items-start gap-2 text-sm p-3 rounded-md border ${
            showSlideshowDebug
              ? 'bg-green-50 text-green-700 border-green-200'
              : 'bg-slate-50 text-slate-600 border-slate-200'
          }`}>
            <Info size={16} className="flex-shrink-0 mt-0.5" />
            <div>
              {showSlideshowDebug ? (
                <span>
                  Debug overlay is <strong>active</strong>. Open the slideshow to view diagnostic information including current image, next image, timing, and status.
                </span>
              ) : (
                <span>
                  Debug overlay is <strong>disabled</strong>. Enable it to see diagnostic information while viewing the slideshow.
                </span>
              )}
            </div>
          </div>

          {/* Explanation */}
          <div className="bg-slate-50 rounded-lg p-4 space-y-2">
            <p className="text-sm font-medium text-slate-900">Debug overlay shows:</p>
            <ul className="text-sm text-slate-600 space-y-1 ml-4 list-disc">
              <li>Active image set name</li>
              <li>Current image index and filename</li>
              <li>Next image on deck (index and filename)</li>
              <li>Fade duration and cycle duration</li>
              <li>Time until next transition (live countdown)</li>
              <li>Playing status and fading state</li>
              <li>Total images in the slideshow</li>
            </ul>
          </div>
        </div>
      </div>
    </div>
  );
}
