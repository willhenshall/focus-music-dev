import { Play, Pause, Presentation } from 'lucide-react';
import { useMusicPlayer } from '../contexts/MusicPlayerContext';
import { useImageSet } from '../contexts/ImageSetContext';

type NowPlayingFooterProps = {
  onOpenSlideshow: () => void;
};

export function NowPlayingFooter({ onOpenSlideshow }: NowPlayingFooterProps) {
  const { activeChannel, isPlaying, currentTrack, toggleChannel } = useMusicPlayer();
  const { channelImages } = useImageSet();

  if (!activeChannel) {
    return null;
  }

  const scrollToActiveChannel = () => {
    const channelCard = document.querySelector(`[data-channel-id="${activeChannel.id}"]`);
    if (channelCard) {
      const header = document.querySelector('header');
      const headerHeight = header ? header.offsetHeight : 0;

      // Add gap spacing (16px on mobile, 20px on desktop matching the grid gap)
      const gapSpacing = window.innerWidth >= 768 ? 20 : 16;

      const cardTop = channelCard.getBoundingClientRect().top + window.scrollY;
      const scrollToPosition = cardTop - headerHeight - gapSpacing;

      window.scrollTo({
        top: scrollToPosition,
        behavior: 'smooth'
      });
    }
  };

  // Use the same logic as the channel cards: prioritize channelImages over image_url
  const channelImage = channelImages[activeChannel.id] || activeChannel.image_url;

  return (
    <div className="fixed bottom-0 left-0 right-0 bg-white border-t border-slate-200 shadow-lg z-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-3 flex items-center justify-between gap-4">
        {/* Left: Now playing info - clickable to scroll to card */}
        <button
          onClick={scrollToActiveChannel}
          className="flex-1 min-w-0 text-left hover:bg-slate-50 -mx-2 px-2 py-1 rounded transition-colors flex items-center gap-3"
        >
          {/* Channel Image */}
          {channelImage && (
            <img
              src={channelImage}
              alt={activeChannel.channel_name}
              className="w-14 h-14 rounded object-cover flex-shrink-0"
            />
          )}

          {/* Text content */}
          <div className="flex-1 min-w-0">
            <div className="text-xs text-slate-500 mb-0.5">Now playing...</div>
            <div className="font-semibold text-slate-900 truncate">
              {activeChannel.channel_name}
            </div>
            <div className="text-sm text-slate-600 truncate">
              {currentTrack?.metadata?.artist_name || 'Unknown Artist'} • {currentTrack?.metadata?.track_name || 'No Track'}
            </div>
          </div>
        </button>

        {/* Center: Play/Pause button */}
        <button
          onClick={() => toggleChannel(activeChannel, !isPlaying, true)}
          className={`w-12 h-12 rounded-full flex items-center justify-center transition-all shadow-md ${
            isPlaying
              ? 'bg-slate-900 text-white hover:bg-slate-800'
              : 'bg-white text-slate-700 hover:bg-slate-50 border-2 border-slate-300'
          }`}
        >
          {isPlaying ? (
            <Pause className="w-5 h-5" fill="currentColor" />
          ) : (
            <Play className="w-5 h-5 ml-0.5" fill="currentColor" />
          )}
        </button>

        {/* Right: Slideshow button */}
        <button
          onClick={onOpenSlideshow}
          className="flex items-center gap-2 px-4 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 font-medium rounded-lg transition-all"
        >
          <Presentation className="w-5 h-5" />
          <span className="hidden sm:inline">Slideshow</span>
        </button>
      </div>
    </div>
  );
}
