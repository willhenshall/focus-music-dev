import { useState, useEffect, useRef, useCallback } from 'react';
import { createPortal } from 'react-dom';
import { X } from 'lucide-react';
import { supabase } from '../lib/supabase';
import { useAuth } from '../contexts/AuthContext';
import { useMusicPlayer } from '../contexts/MusicPlayerContext';
import TimerDebugOverlay from './TimerDebugOverlay';

interface SessionTimerProps {
  isPlaying?: boolean;
  onTimerEnd?: () => void;
}

export default function SessionTimer({ isPlaying: isPlayingProp, onTimerEnd = () => {} }: SessionTimerProps) {
  const { user } = useAuth();
  const { isPlaying: isPlayingFromContext } = useMusicPlayer();
  // Use prop if provided, otherwise use context
  const isPlaying = isPlayingProp !== undefined ? isPlayingProp : isPlayingFromContext;
  const [isTimerActive, setIsTimerActive] = useState(false);
  const [timerDuration, setTimerDuration] = useState(0); // in seconds
  const [remainingTime, setRemainingTime] = useState(0); // in seconds
  const [lastSetDuration, setLastSetDuration] = useState(1500); // Remember last set duration (default 25 min)
  const [showModal, setShowModal] = useState(false);
  const [inputMinutes, setInputMinutes] = useState('25');
  const intervalRef = useRef<number | null>(null);
  const audioContextRef = useRef<AudioContext | null>(null);
  const hasPlayedStartBell = useRef(false);
  const timerDurationRef = useRef(0);
  const effectRunCount = useRef(0);
  const onTimerEndRef = useRef(onTimerEnd);
  const [isLoading, setIsLoading] = useState(true);
  const [customBellUrl, setCustomBellUrl] = useState<string | null>(null);
  const customBellAudioRef = useRef<HTMLAudioElement | null>(null);
  const [showDebug, setShowDebug] = useState(false);

  // Keep the ref updated with the latest callback
  useEffect(() => {
    console.log('⏰ SessionTimer: Updating onTimerEndRef with new callback');
    console.log('⏰ SessionTimer: New callback type:', typeof onTimerEnd);
    console.log('⏰ SessionTimer: New callback function:', onTimerEnd);
    onTimerEndRef.current = onTimerEnd;
    console.log('⏰ SessionTimer: onTimerEndRef.current after update:', onTimerEndRef.current);
  }, [onTimerEnd]);

  // Initialize audio context
  useEffect(() => {
    audioContextRef.current = new (window.AudioContext || (window as any).webkitAudioContext)();
    return () => {
      if (audioContextRef.current) {
        audioContextRef.current.close();
      }
    };
  }, []);

  // Load custom bell URL from system preferences
  useEffect(() => {
    const loadCustomBell = async () => {
      try {
        const { data, error } = await supabase
          .from('system_preferences')
          .select('timer_bell_url')
          .maybeSingle();

        if (error) throw error;

        if (data?.timer_bell_url) {
          setCustomBellUrl(data.timer_bell_url);
          // Preload the audio
          const audio = new Audio(data.timer_bell_url);
          audio.preload = 'auto';
          customBellAudioRef.current = audio;
        }
      } catch (error) {
        console.error('Error loading custom bell URL:', error);
      }
    };

    loadCustomBell();
  }, []);


  // Load timer preferences from database
  useEffect(() => {
    const loadTimerPreferences = async () => {
      if (!user) {
        setIsLoading(false);
        return;
      }

      try {
        const { data, error } = await supabase
          .from('user_preferences')
          .select('session_timer_duration, session_timer_enabled, show_timer_debug')
          .eq('user_id', user.id)
          .maybeSingle();

        if (error) throw error;

        if (data) {
          const duration = data.session_timer_duration || 1500;
          const minutes = Math.floor(duration / 60);
          setInputMinutes(minutes.toString());
          setLastSetDuration(duration); // Remember the saved duration
          setShowDebug(data.show_timer_debug || false);

          if (data.session_timer_enabled) {
            setTimerDuration(duration);
            setRemainingTime(duration);
            setIsTimerActive(true);
          } else {
            // Even if timer is not active, show the last set duration
            setRemainingTime(duration);
          }
        }
      } catch (error) {
        console.error('Error loading timer preferences:', error);
      } finally {
        setIsLoading(false);
      }
    };

    loadTimerPreferences();
  }, [user]);

  // Subscribe to debug preference changes
  useEffect(() => {
    if (!user) return;

    const channel = supabase
      .channel('timer-debug-changes')
      .on(
        'postgres_changes',
        {
          event: 'UPDATE',
          schema: 'public',
          table: 'user_preferences',
          filter: `user_id=eq.${user.id}`,
        },
        (payload) => {
          if (payload.new && 'show_timer_debug' in payload.new) {
            setShowDebug(payload.new.show_timer_debug);
          }
        }
      )
      .subscribe();

    return () => {
      channel.unsubscribe();
    };
  }, [user]);

  // Save timer preferences to database
  const saveTimerPreferences = useCallback(async (duration: number, enabled: boolean) => {
    if (!user) return;

    try {
      const { error } = await supabase
        .from('user_preferences')
        .upsert({
          user_id: user.id,
          session_timer_duration: duration,
          session_timer_enabled: enabled,
          updated_at: new Date().toISOString(),
        }, {
          onConflict: 'user_id',
        });

      if (error) throw error;
    } catch (error) {
      console.error('Error saving timer preferences:', error);
    }
  }, [user]);

  const playProgrammaticBell = () => {
    if (!audioContextRef.current) return;

    const ctx = audioContextRef.current;
    const oscillator = ctx.createOscillator();
    const gainNode = ctx.createGain();

    oscillator.connect(gainNode);
    gainNode.connect(ctx.destination);

    // Create a pleasant bell-like sound
    oscillator.type = 'sine';
    oscillator.frequency.setValueAtTime(800, ctx.currentTime);
    oscillator.frequency.exponentialRampToValueAtTime(400, ctx.currentTime + 0.5);

    gainNode.gain.setValueAtTime(0.3, ctx.currentTime);
    gainNode.gain.exponentialRampToValueAtTime(0.01, ctx.currentTime + 1.5);

    oscillator.start(ctx.currentTime);
    oscillator.stop(ctx.currentTime + 1.5);
  };

  // Play bell sound
  const playBell = () => {
    // If custom bell is available, play it
    if (customBellAudioRef.current) {
      customBellAudioRef.current.currentTime = 0;
      customBellAudioRef.current.play().catch(err => {
        console.error('Error playing custom bell:', err);
        // Fall back to programmatic bell if custom fails
        playProgrammaticBell();
      });
      return;
    }

    // Otherwise use programmatic bell
    playProgrammaticBell();
  };

  // Timer countdown logic
  useEffect(() => {
    effectRunCount.current += 1;
    console.log('Timer effect running, count:', effectRunCount.current, 'isTimerActive:', isTimerActive, 'isPlaying:', isPlaying);

    if (isTimerActive && isPlaying) {
      // Play start bell when timer starts with playback
      if (!hasPlayedStartBell.current) {
        playBell();
        hasPlayedStartBell.current = true;
      }

      console.log('Starting interval...');
      intervalRef.current = window.setInterval(() => {
        console.log('Interval tick');
        setRemainingTime((prev) => {
          console.log('Setting remaining time from', prev, 'to', prev - 1);
          if (prev <= 1) {
            // Timer finished - clear interval first
            console.log('⏰ TIMER COMPLETED - Clearing interval');
            if (intervalRef.current) {
              clearInterval(intervalRef.current);
              intervalRef.current = null;
            }

            console.log('⏰ Playing bell and calling onTimerEnd callback');
            playBell();

            // Call the callback to stop music
            console.log('⏰ About to call onTimerEndRef.current');
            console.log('⏰ onTimerEndRef.current type:', typeof onTimerEndRef.current);
            console.log('⏰ onTimerEndRef.current function:', onTimerEndRef.current);
            try {
              console.error('!!!!! CALLING TIMER END CALLBACK NOW !!!!!');
              onTimerEndRef.current();
              console.log('⏰ Successfully called onTimerEnd callback');
            } catch (error) {
              console.error('⏰ Error calling onTimerEnd callback:', error);
            }

            console.log('⏰ Setting timer inactive');
            setIsTimerActive(false);
            hasPlayedStartBell.current = false;

            // Reset to last set duration after completion
            const finalDuration = timerDurationRef.current;

            // Save timer ended state (using captured values to avoid closure issues)
            if (user) {
              supabase
                .from('user_preferences')
                .upsert({
                  user_id: user.id,
                  session_timer_duration: finalDuration,
                  session_timer_enabled: false,
                  updated_at: new Date().toISOString(),
                }, {
                  onConflict: 'user_id',
                })
                .then(() => {})
                .catch(error => console.error('Error saving timer preferences:', error));
            }
            return finalDuration;
          }
          return prev - 1;
        });
      }, 1000);

      return () => {
        console.log('Cleaning up interval');
        if (intervalRef.current) {
          clearInterval(intervalRef.current);
        }
      };
    } else {
      console.log('Not starting interval - isTimerActive:', isTimerActive, 'isPlaying:', isPlaying);
      // Clear interval when paused
      if (intervalRef.current) {
        clearInterval(intervalRef.current);
        intervalRef.current = null;
      }
      // Reset start bell flag when stopped
      if (!isPlaying) {
        hasPlayedStartBell.current = false;
      }
    }
  }, [isTimerActive, isPlaying, user]);

  const handleSetTimer = async () => {
    const minutes = parseInt(inputMinutes) || 25;
    const seconds = minutes * 60;
    console.log('⏰ SETTING TIMER:', seconds, 'seconds (', minutes, 'minutes), isPlaying:', isPlaying);
    setTimerDuration(seconds);
    timerDurationRef.current = seconds;
    setLastSetDuration(seconds); // Remember this duration
    setRemainingTime(seconds);
    setIsTimerActive(true);
    setShowModal(false);
    hasPlayedStartBell.current = false;

    // If music is already playing, start timer immediately with bell
    if (isPlaying) {
      console.log('⏰ Music already playing, will start bell on next effect');
      playBell();
      hasPlayedStartBell.current = true;
    } else {
      console.log('⏰ Music not playing yet, timer will start when music plays');
    }

    await saveTimerPreferences(seconds, true);
    console.log('⏰ Timer preferences saved');
  };

  const handleCancelTimer = useCallback(async () => {
    setIsTimerActive(false);
    setRemainingTime(lastSetDuration); // Reset to last set duration
    setTimerDuration(lastSetDuration);
    hasPlayedStartBell.current = false;
    if (intervalRef.current) {
      clearInterval(intervalRef.current);
    }
    setShowModal(false); // Close the modal after cancelling
    await saveTimerPreferences(lastSetDuration, false);
  }, [lastSetDuration, saveTimerPreferences]);

  // Handle Enter key to cancel timer when modal is open and timer is active
  useEffect(() => {
    if (!showModal || !isTimerActive) return;

    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Enter') {
        e.preventDefault();
        handleCancelTimer();
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [showModal, isTimerActive, handleCancelTimer]);

  const formatTime = (seconds: number): string => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins}:${secs.toString().padStart(2, '0')}`;
  };

  const getDisplayMinutes = (): string => {
    const mins = Math.floor(remainingTime / 60);
    return mins.toString();
  };

  const getBellFileName = (): string => {
    if (customBellUrl) {
      // Extract filename from URL
      try {
        const url = new URL(customBellUrl);
        const pathParts = url.pathname.split('/');
        return pathParts[pathParts.length - 1] || 'custom-bell.mp3';
      } catch {
        return 'custom-bell.mp3';
      }
    }
    return 'default-bell.mp3 (built-in)';
  };

  return (
    <>
      {/* Debug Overlay */}
      {showDebug && (
        <TimerDebugOverlay
          isTimerActive={isTimerActive}
          remainingTime={remainingTime}
          timerDuration={timerDuration}
          isPlaying={isPlaying}
          lastSetDuration={lastSetDuration}
          hasPlayedStartBell={hasPlayedStartBell.current}
          effectRunCount={effectRunCount.current}
          intervalActive={intervalRef.current !== null}
        />
      )}

      {/* Timer Display Button - Console Style */}
      <button
        onClick={() => {
          if (isTimerActive) {
            // Show cancel dialog if timer is active
            setShowModal(true);
          } else {
            // Show setup dialog if timer is not active
            setShowModal(true);
          }
        }}
        className={`px-3 py-1.5 rounded-xl text-lg font-semibold tabular-nums transition-all ${
          isTimerActive && isPlaying
            ? 'bg-blue-50 border-2 border-blue-200 text-blue-700 hover:bg-blue-100 hover:border-blue-300 shadow-sm'
            : isTimerActive && !isPlaying
            ? 'bg-amber-50 border-2 border-amber-300 text-amber-700 hover:bg-amber-100 shadow-sm'
            : 'bg-slate-50 border-2 border-slate-200 text-slate-500 hover:bg-slate-100 hover:border-slate-300 shadow-sm'
        }`}
        title={isTimerActive ? 'Click to cancel timer' : 'Click to set timer'}
      >
        {isTimerActive && remainingTime > 0 ? formatTime(remainingTime) : formatTime(lastSetDuration)}
      </button>

      {/* Timer Settings Modal */}
      {showModal && createPortal(
        <div
          className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4"
          style={{ zIndex: 9999 }}
          onClick={() => setShowModal(false)}
        >
          <div
            className="bg-white rounded-xl shadow-2xl max-w-sm w-full p-6"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="flex items-center justify-between mb-6">
              <h2 className="text-xl font-bold text-slate-900">Session Timer</h2>
              <button
                onClick={() => setShowModal(false)}
                className="p-2 hover:bg-slate-100 rounded-lg transition-colors"
              >
                <X size={20} className="text-slate-600" />
              </button>
            </div>

            {isTimerActive ? (
              <div className="space-y-6">
                <div className="text-center">
                  <div className="text-5xl font-bold text-blue-600 mb-2">
                    {formatTime(remainingTime)}
                  </div>
                  <p className="text-slate-600">
                    {isPlaying ? 'Timer is running' : 'Timer is paused'}
                  </p>
                </div>
                <button
                  onClick={handleCancelTimer}
                  className="w-full px-6 py-3 bg-red-600 text-white rounded-lg hover:bg-red-700 transition-colors font-medium"
                >
                  Cancel Timer
                </button>
              </div>
            ) : (
              <div className="space-y-6">
                <div className="text-center space-y-4">
                  <div className="relative">
                    <input
                      type="number"
                      value={inputMinutes}
                      onChange={(e) => setInputMinutes(e.target.value)}
                      onKeyDown={(e) => {
                        if (e.key === 'Enter') {
                          handleSetTimer();
                        }
                      }}
                      min="1"
                      max="180"
                      className="w-full text-center text-5xl font-bold text-blue-600 bg-transparent border-none focus:outline-none focus:ring-0 py-2"
                      placeholder="25"
                    />
                    <div className="text-slate-500 text-sm mt-1">minutes</div>
                  </div>
                  <p className="text-slate-600 text-sm">
                    Set a timer from 1 to 180 minutes
                  </p>
                </div>

                <button
                  onClick={handleSetTimer}
                  className="w-full px-6 py-3 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors font-medium"
                >
                  Set Timer
                </button>
              </div>
            )}
          </div>
        </div>,
        document.body
      )}
    </>
  );
}
