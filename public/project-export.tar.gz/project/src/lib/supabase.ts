import { createClient } from '@supabase/supabase-js';

const supabaseUrl = import.meta.env.VITE_SUPABASE_URL;
const supabaseAnonKey = import.meta.env.VITE_SUPABASE_ANON_KEY;

if (!supabaseUrl || !supabaseAnonKey) {
  throw new Error('Missing Supabase environment variables');
}

export const supabase = createClient(supabaseUrl, supabaseAnonKey);

export type UserProfile = {
  id: string;
  brain_type: string | null;
  ocean_openness: number;
  ocean_conscientiousness: number;
  ocean_extraversion: number;
  ocean_agreeableness: number;
  ocean_neuroticism: number;
  adhd_indicator: number;
  asd_indicator: number;
  prefers_music: boolean;
  energy_preference: string;
  onboarding_completed: boolean;
  is_admin: boolean;
  display_name: string;
  created_at: string;
  updated_at: string;
};

export type PlaylistStrategy = 'track_id_order' | 'weighted' | 'filename' | 'upload_date' | 'random' | 'custom';

export type AudioChannel = {
  id: string;
  channel_number: number;
  channel_name: string;
  description: string | null;
  brain_type_affinity: string[];
  neuroscience_tags: string[];
  playlist_data: {
    low: string[];
    medium: string[];
    high: string[];
  };
  playlist_strategy?: {
    low: { strategy: PlaylistStrategy; noRepeatWindow?: number };
    medium: { strategy: PlaylistStrategy; noRepeatWindow?: number };
    high: { strategy: PlaylistStrategy; noRepeatWindow?: number };
  };
  image_url: string | null;
  created_at: string;
};

export type AudioTrack = {
  id: string;
  channel_id: string;
  energy_level: 'low' | 'medium' | 'high';
  file_path: string;
  duration_seconds: number;
  metadata: Record<string, any>;
  skip_rate: number;
  is_preview: boolean;
  preview_channel_id?: string | null;
  created_at: string;
  deleted_at?: string | null;
  deleted_by?: string | null;
};

export type ListeningSession = {
  id: string;
  user_id: string;
  channel_id: string | null;
  energy_level: string | null;
  started_at: string;
  ended_at: string | null;
  total_duration_seconds: number;
  tracks_played: string[];
  tracks_skipped: string[];
  productivity_rating: number | null;
};

export type ChannelRecommendation = {
  id: string;
  user_id: string;
  channel_id: string;
  confidence_score: number;
  reasoning: string | null;
  is_active: boolean;
  created_at: string;
};
