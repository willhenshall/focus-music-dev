import { useState, useEffect } from 'react';
import { AuthProvider, useAuth } from './contexts/AuthContext';
import { MusicPlayerProvider } from './contexts/MusicPlayerContext';
import { ImageSetProvider } from './contexts/ImageSetContext';
import { NowPlayingFooter } from './components/NowPlayingFooter';
import { SlideshowOverlay } from './components/SlideshowOverlay';
import { LandingPage } from './components/LandingPage';
import { AuthForm } from './components/AuthForm';
import { OnboardingQuiz } from './components/OnboardingQuiz';
import { QuizResultsPage } from './components/QuizResultsPage';
import { UserDashboard } from './components/UserDashboard';
import { AdminDashboard } from './components/AdminDashboard';
import { supabase } from './lib/supabase';
import { BrainType } from './lib/brainTypeCalculator';

function AppContent() {
  const { user, profile, loading, signOut } = useAuth();
  const [authMode, setAuthMode] = useState<'signin' | 'signup'>('signin');
  const [showAuth, setShowAuth] = useState(false);
  const [viewMode, setViewMode] = useState<'user' | 'admin'>('user');
  const [initialTab, setInitialTab] = useState<'channels' | 'focus-profile' | 'images' | 'settings'>('channels');
  const [isAccessGranted, setIsAccessGranted] = useState(false);
  const [passwordInput, setPasswordInput] = useState('');
  const [passwordError, setPasswordError] = useState('');
  const [showQuiz, setShowQuiz] = useState(false);
  const [quizResults, setQuizResults] = useState<string[] | null>(null);
  const [quizBrainType, setQuizBrainType] = useState<{ primary: BrainType; secondary?: BrainType; secondaryScore?: number } | null>(null);
  const [quizCognitiveProfile, setQuizCognitiveProfile] = useState<{ adhdIndicator: number; asdScore: number; stimulantLevel: string } | null>(null);
  const [showDiagnostics, setShowDiagnostics] = useState(true);
  const [showQueue, setShowQueue] = useState(true);
  const [isRetakingQuiz, setIsRetakingQuiz] = useState(false);
  const [showSlideshow, setShowSlideshow] = useState(false);

  console.log('AppContent render:', {
    hasUser: !!user,
    hasProfile: !!profile,
    onboardingCompleted: profile?.onboarding_completed,
    loading,
    showAuth,
    initialTab,
    isRetakingQuiz
  });

  const handleLogoClick = async () => {
    if (user) {
      await signOut();
    }
    setShowAuth(false);
    setShowQuiz(false);
    setQuizResults(null);
    setQuizBrainType(null);
    setQuizCognitiveProfile(null);
    setAuthMode('signin');
  };

  useEffect(() => {
    const accessGranted = localStorage.getItem('site_access_granted');
    if (accessGranted === 'true') {
      setIsAccessGranted(true);
    }

    // Check if user wants to retake quiz
    const urlParams = new URLSearchParams(window.location.search);
    if (urlParams.get('retake-quiz') === 'true') {
      setIsRetakingQuiz(true);
      // Clean up URL
      window.history.replaceState({}, '', window.location.pathname);
    }
  }, []);

  useEffect(() => {
    loadAudioPreferences();

    const handlePreferencesChanged = (event: CustomEvent) => {
      setShowDiagnostics(event.detail.show_audio_diagnostics);
      setShowQueue(event.detail.show_queue);
    };

    window.addEventListener('audioPreferencesChanged', handlePreferencesChanged as EventListener);

    return () => {
      window.removeEventListener('audioPreferencesChanged', handlePreferencesChanged as EventListener);
    };
  }, []);

  const loadAudioPreferences = async () => {
    const { data } = await supabase
      .from('system_preferences')
      .select('show_audio_diagnostics, show_queue')
      .eq('id', 1)
      .maybeSingle();

    if (data) {
      setShowDiagnostics(data.show_audio_diagnostics ?? false);
      setShowQueue(data.show_queue ?? true);
    }
  };

  const handlePasswordSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (passwordInput.toLowerCase() === 'magic') {
      localStorage.setItem('site_access_granted', 'true');
      setIsAccessGranted(true);
      setPasswordError('');
    } else {
      setPasswordError('Incorrect password. Please try again.');
      setPasswordInput('');
    }
  };

  if (!isAccessGranted && !user) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-50 to-slate-100 flex items-center justify-center p-4">
        <div className="bg-white rounded-2xl shadow-lg p-8 max-w-md w-full">
          <div className="text-center mb-6">
            <h1 className="text-3xl text-slate-900 mb-2">
              <span className="font-bold">focus</span><span className="font-normal">.music</span>
            </h1>
            <p className="text-slate-600">Enter password to continue</p>
          </div>

          <form onSubmit={handlePasswordSubmit} className="space-y-4">
            <div>
              <label htmlFor="password" className="block text-sm font-medium text-slate-700 mb-2">
                Password
              </label>
              <input
                id="password"
                type="password"
                value={passwordInput}
                onChange={(e) => setPasswordInput(e.target.value)}
                className="w-full px-4 py-3 border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                placeholder="Enter password"
                autoFocus
              />
            </div>

            {passwordError && (
              <div className="text-sm text-red-600 bg-red-50 p-3 rounded-lg">
                {passwordError}
              </div>
            )}

            <button
              type="submit"
              className="w-full bg-slate-900 hover:bg-slate-800 text-white font-semibold py-3 px-4 rounded-lg transition-colors"
            >
              Continue
            </button>
          </form>
        </div>
      </div>
    );
  }

  if (loading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-50 to-slate-100 flex items-center justify-center">
        <div className="text-center">
          <div className="inline-block animate-spin rounded-full h-12 w-12 border-4 border-blue-500 border-t-transparent" />
          <p className="mt-4 text-slate-600">Loading...</p>
        </div>
      </div>
    );
  }

  if (!user) {
    if (showAuth) {
      return (
        <AuthForm
          mode={authMode}
          onModeChange={setAuthMode}
          onSuccess={() => {
            console.log('Auth success - setting initial tab to channels');
            // Set initial tab FIRST before clearing other state
            setInitialTab('channels');
            setShowAuth(false);
            setQuizResults(null);
            setQuizBrainType(null);
            setQuizCognitiveProfile(null);
            console.log('Auth success complete - should show channels page');
          }}
          onLogoClick={handleLogoClick}
        />
      );
    }
    if (quizResults) {
      return (
        <QuizResultsPage
          topChannelIds={quizResults}
          brainType={quizBrainType || undefined}
          cognitiveProfile={quizCognitiveProfile || undefined}
          onStartTrial={() => {
            setAuthMode('signup');
            setShowAuth(true);
          }}
          onSignIn={() => {
            setAuthMode('signin');
            setShowAuth(true);
          }}
          onLogoClick={handleLogoClick}
        />
      );
    }
    if (showQuiz) {
      return (
        <OnboardingQuiz
          isAnonymous={true}
          onComplete={(topChannels, brainType, cognitiveProfile) => {
            console.log('App received topChannels:', topChannels);
            console.log('App received brainType:', brainType);
            console.log('App received cognitiveProfile:', cognitiveProfile);
            if (topChannels && topChannels.length > 0) {
              const channelIds = topChannels.map(ch => ch.channel_id);
              console.log('Setting quiz results with IDs:', channelIds);
              setQuizResults(channelIds);
              setQuizBrainType(brainType || null);
              setQuizCognitiveProfile(cognitiveProfile || null);
              setShowQuiz(false);
            } else {
              console.error('No top channels received from quiz');
            }
          }}
          onLogoClick={handleLogoClick}
        />
      );
    }
    return (
      <LandingPage
        onAuthModeChange={(mode) => {
          setAuthMode(mode);
          setShowAuth(true);
        }}
        onStartQuiz={() => setShowQuiz(true)}
      />
    );
  }

  // Handle retaking quiz for logged-in users
  if (isRetakingQuiz) {
    return (
      <OnboardingQuiz
        onComplete={() => {
          setIsRetakingQuiz(false);
          setInitialTab('channels');
        }}
        onLogoClick={() => {
          setIsRetakingQuiz(false);
          handleLogoClick();
        }}
      />
    );
  }

  if (profile?.is_admin) {
    if (viewMode === 'admin') {
      return (
        <>
          <AdminDashboard onSwitchToUser={() => setViewMode('user')} />
          <NowPlayingFooter onOpenSlideshow={() => setShowSlideshow(true)} />
          {showSlideshow && <SlideshowOverlay onClose={() => setShowSlideshow(false)} />}
        </>
      );
    }
    if (!profile?.onboarding_completed) {
      return <OnboardingQuiz onComplete={() => setInitialTab('channels')} onLogoClick={handleLogoClick} />;
    }
    return (
      <>
        <UserDashboard initialTab={initialTab} onSwitchToAdmin={() => setViewMode('admin')} />
        <NowPlayingFooter onOpenSlideshow={() => setShowSlideshow(true)} />
        {showSlideshow && <SlideshowOverlay onClose={() => setShowSlideshow(false)} />}
      </>
    );
  }

  if (!profile?.onboarding_completed) {
    return <OnboardingQuiz onComplete={() => setInitialTab('channels')} onLogoClick={handleLogoClick} />;
  }

  return (
    <>
      <UserDashboard initialTab={initialTab} />
      <NowPlayingFooter onOpenSlideshow={() => setShowSlideshow(true)} />
      {showSlideshow && <SlideshowOverlay onClose={() => setShowSlideshow(false)} />}
    </>
  );
}

function App() {
  return (
    <AuthProvider>
      <MusicPlayerProvider>
        <ImageSetProvider>
          <AppContent />
        </ImageSetProvider>
      </MusicPlayerProvider>
    </AuthProvider>
  );
}

export default App;
