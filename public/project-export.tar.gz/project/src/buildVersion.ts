// Update this number each time you deploy a new build
// This helps track which build version is running in production
export const BUILD_VERSION = 964;
