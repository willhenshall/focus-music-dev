import { createContext, useContext, useEffect, useState, ReactNode } from 'react';
import { User, Session } from '@supabase/supabase-js';
import { supabase, UserProfile } from '../lib/supabase';
import { saveQuizResultsToDatabase } from '../lib/quizStorage';

type AuthContextType = {
  user: User | null;
  profile: UserProfile | null;
  session: Session | null;
  loading: boolean;
  signUp: (email: string, password: string) => Promise<{ error: any }>;
  signIn: (email: string, password: string) => Promise<{ error: any }>;
  signOut: () => Promise<void>;
  refreshProfile: () => Promise<void>;
};

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export function AuthProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<User | null>(null);
  const [profile, setProfile] = useState<UserProfile | null>(null);
  const [session, setSession] = useState<Session | null>(null);
  const [loading, setLoading] = useState(true);

  const fetchProfile = async (userId: string) => {
    const { data, error } = await supabase
      .from('user_profiles')
      .select('*')
      .eq('id', userId)
      .maybeSingle();

    if (!error && data) {
      setProfile(data);
    } else if (!error && !data) {
      await supabase.auth.signOut();
      setUser(null);
      setProfile(null);
    }
  };

  const refreshProfile = async () => {
    if (user) {
      await fetchProfile(user.id);
    }
  };

  useEffect(() => {
    supabase.auth.getSession().then(({ data: { session } }) => {
      setSession(session);
      setUser(session?.user ?? null);
      if (session?.user) {
        fetchProfile(session.user.id);
      }
      setLoading(false);
    });

    const { data: { subscription } } = supabase.auth.onAuthStateChange((_event, session) => {
      (async () => {
        setSession(session);
        setUser(session?.user ?? null);
        if (session?.user) {
          await fetchProfile(session.user.id);
        } else {
          setProfile(null);
        }
        setLoading(false);
      })();
    });

    return () => subscription.unsubscribe();
  }, []);

  const signUp = async (email: string, password: string) => {
    const { data, error } = await supabase.auth.signUp({
      email,
      password,
      options: {
        emailRedirectTo: window.location.origin,
      }
    });

    if (error) {
      return { error };
    }

    if (!data.user) {
      return { error: new Error('Failed to create user') };
    }

    // Check if email confirmation is required
    if (!data.session) {
      return {
        error: new Error('Email confirmation is enabled. Please check your Supabase settings to disable email confirmation for immediate signup.')
      };
    }

    // User is signed up with an active session
    const hasQuizResults = localStorage.getItem('quiz_results');

    // Insert user profile
    const { error: profileError } = await supabase.from('user_profiles').insert({
      id: data.user.id,
      onboarding_completed: hasQuizResults ? true : false,
    });

    if (profileError) {
      console.error('Error creating user profile:', profileError);
      return { error: profileError };
    }

    // Save quiz results if they exist
    if (hasQuizResults) {
      try {
        await saveQuizResultsToDatabase(data.user.id);
        console.log('Quiz results saved to database for new user');
      } catch (quizError) {
        console.error('Error saving quiz results:', quizError);
      }
    }

    // Set the user and session immediately so the app knows we're authenticated
    setUser(data.user);
    setSession(data.session);

    // Wait for profile to be fully loaded before returning
    await fetchProfile(data.user.id);

    console.log('Sign up complete - user and profile set:', { userId: data.user.id, hasProfile: true, onboardingCompleted: hasQuizResults });

    return { error: null };
  };

  const signIn = async (email: string, password: string) => {
    const { error } = await supabase.auth.signInWithPassword({
      email,
      password,
    });

    return { error };
  };

  const signOut = async () => {
    await supabase.auth.signOut();
    setProfile(null);
  };

  return (
    <AuthContext.Provider
      value={{
        user,
        profile,
        session,
        loading,
        signUp,
        signIn,
        signOut,
        refreshProfile,
      }}
    >
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
}
