import { useState, useEffect } from 'react';
import { Upload, Play, Trash2, Bell } from 'lucide-react';
import { supabase } from '../lib/supabase';

export function TimerBellSettings() {
  const [currentBellUrl, setCurrentBellUrl] = useState<string | null>(null);
  const [uploading, setUploading] = useState(false);
  const [testing, setTesting] = useState(false);
  const [audioRef, setAudioRef] = useState<HTMLAudioElement | null>(null);

  useEffect(() => {
    loadCurrentBell();
  }, []);

  const loadCurrentBell = async () => {
    try {
      const { data, error } = await supabase
        .from('system_preferences')
        .select('timer_bell_url')
        .maybeSingle();

      if (error) throw error;

      if (data?.timer_bell_url) {
        setCurrentBellUrl(data.timer_bell_url);
      }
    } catch (error) {
      console.error('Error loading timer bell:', error);
    }
  };

  const handleFileUpload = async (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;

    // Validate file type
    const validTypes = ['audio/mpeg', 'audio/mp3', 'audio/wav', 'audio/ogg', 'audio/webm'];
    if (!validTypes.includes(file.type)) {
      alert('Please upload a valid audio file (MP3, WAV, OGG, or WebM)');
      return;
    }

    // Validate file size (max 5MB)
    if (file.size > 5 * 1024 * 1024) {
      alert('File size must be less than 5MB');
      return;
    }

    setUploading(true);

    try {
      // Delete existing bell if it exists
      if (currentBellUrl) {
        const existingPath = currentBellUrl.split('/timer-bell/')[1];
        if (existingPath) {
          const { error: deleteError } = await supabase.storage
            .from('timer-bell')
            .remove([existingPath]);

          if (deleteError) {
            console.warn('Error deleting existing bell:', deleteError);
            // Continue anyway - might not exist
          }
        }
      }

      // Upload new file
      const fileExt = file.name.split('.').pop();
      const fileName = `timer-bell.${fileExt}`;
      const filePath = fileName;

      console.log('Uploading timer bell:', { fileName, fileSize: file.size, fileType: file.type });

      const { data: uploadData, error: uploadError } = await supabase.storage
        .from('timer-bell')
        .upload(filePath, file, {
          cacheControl: '3600',
          upsert: true,
        });

      if (uploadError) {
        console.error('Upload error:', uploadError);
        throw new Error(`Upload failed: ${uploadError.message}`);
      }

      console.log('Upload successful:', uploadData);

      // Get public URL
      const { data: { publicUrl } } = supabase.storage
        .from('timer-bell')
        .getPublicUrl(filePath);

      console.log('Public URL:', publicUrl);

      // Update system preferences
      const { error: updateError } = await supabase
        .from('system_preferences')
        .upsert({
          id: 1,
          timer_bell_url: publicUrl,
          updated_at: new Date().toISOString(),
        });

      if (updateError) {
        console.error('Database update error:', updateError);
        throw new Error(`Database update failed: ${updateError.message}`);
      }

      setCurrentBellUrl(publicUrl);
      alert('Timer bell uploaded successfully!');
    } catch (error: any) {
      console.error('Error uploading timer bell:', error);
      alert(`Failed to upload timer bell: ${error.message || 'Please try again.'}`);
    } finally {
      setUploading(false);
    }
  };

  const handleTestBell = async () => {
    if (!currentBellUrl) return;

    setTesting(true);

    try {
      const audio = new Audio(currentBellUrl);
      setAudioRef(audio);

      audio.onended = () => {
        setTesting(false);
      };

      audio.onerror = () => {
        setTesting(false);
        alert('Failed to play bell sound');
      };

      await audio.play();
    } catch (error) {
      console.error('Error playing bell:', error);
      setTesting(false);
      alert('Failed to play bell sound');
    }
  };

  const handleDeleteBell = async () => {
    if (!currentBellUrl) return;

    if (!confirm('Are you sure you want to delete the custom timer bell? This will revert to the default bell sound.')) {
      return;
    }

    try {
      // Delete from storage
      const filePath = currentBellUrl.split('/timer-bell/')[1];
      if (filePath) {
        const { error: deleteError } = await supabase.storage
          .from('timer-bell')
          .remove([filePath]);

        if (deleteError) throw deleteError;
      }

      // Update system preferences to null
      const { error: updateError } = await supabase
        .from('system_preferences')
        .upsert({
          id: 1,
          timer_bell_url: null,
          updated_at: new Date().toISOString(),
        });

      if (updateError) throw updateError;

      setCurrentBellUrl(null);
      if (audioRef) {
        audioRef.pause();
        setAudioRef(null);
      }
      alert('Custom timer bell deleted. Default bell will be used.');
    } catch (error) {
      console.error('Error deleting timer bell:', error);
      alert('Failed to delete timer bell. Please try again.');
    }
  };

  return (
    <div className="space-y-6">
      <div className="bg-white rounded-xl shadow-sm border border-slate-200 overflow-hidden">
        <div className="px-6 py-4 border-b border-slate-200 bg-slate-50">
          <div className="flex items-center gap-3">
            <Bell className="text-slate-700" size={24} />
            <div>
              <h2 className="text-xl font-semibold text-slate-900">Timer Bell Sound</h2>
              <p className="text-sm text-slate-600 mt-1">
                Upload a custom audio file to play when the session timer starts and ends
              </p>
            </div>
          </div>
        </div>

        <div className="p-6 space-y-6">
          {/* Current Bell Status */}
          <div className="bg-slate-50 rounded-lg p-4">
            <h3 className="font-medium text-slate-900 mb-2">Current Bell</h3>
            {currentBellUrl ? (
              <div className="flex items-center justify-between">
                <p className="text-sm text-slate-600">Custom bell uploaded</p>
                <div className="flex gap-2">
                  <button
                    onClick={handleTestBell}
                    disabled={testing}
                    className="px-3 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors disabled:opacity-50 disabled:cursor-not-allowed flex items-center gap-2"
                  >
                    <Play size={16} />
                    {testing ? 'Playing...' : 'Test'}
                  </button>
                  <button
                    onClick={handleDeleteBell}
                    className="px-3 py-2 bg-red-600 text-white rounded-lg hover:bg-red-700 transition-colors flex items-center gap-2"
                  >
                    <Trash2 size={16} />
                    Delete
                  </button>
                </div>
              </div>
            ) : (
              <p className="text-sm text-slate-600">Using default programmatic bell sound</p>
            )}
          </div>

          {/* Upload New Bell */}
          <div>
            <h3 className="font-medium text-slate-900 mb-3">Upload New Bell</h3>
            <div className="border-2 border-dashed border-slate-300 rounded-lg p-8 text-center hover:border-blue-400 transition-colors">
              <input
                type="file"
                id="bell-upload"
                accept="audio/*"
                onChange={handleFileUpload}
                disabled={uploading}
                className="hidden"
              />
              <label
                htmlFor="bell-upload"
                className={`cursor-pointer flex flex-col items-center gap-3 ${
                  uploading ? 'opacity-50 cursor-not-allowed' : ''
                }`}
              >
                <Upload className="text-slate-400" size={48} />
                <div>
                  <p className="text-sm font-medium text-slate-700">
                    {uploading ? 'Uploading...' : 'Click to upload or drag and drop'}
                  </p>
                  <p className="text-xs text-slate-500 mt-1">
                    MP3, WAV, OGG, or WebM (max 5MB)
                  </p>
                </div>
              </label>
            </div>
          </div>

          {/* Info */}
          <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
            <p className="text-sm text-blue-800">
              <strong>Tip:</strong> For best results, use a short audio file (1-3 seconds) with a clear, pleasant sound.
              The bell will play when users start a timer session and when it ends.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}
