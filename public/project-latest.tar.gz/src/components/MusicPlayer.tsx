import { Play, Pause, Volume2, X, ChevronDown, ChevronUp, SkipForward, Maximize2, Minimize2 } from 'lucide-react';
import { useMusicPlayer } from '../contexts/MusicPlayerContext';
import { useImageSet } from '../contexts/ImageSetContext';
import { useState, useEffect, useRef, useCallback } from 'react';
import { HTML5AudioDiagnostics } from './HTML5AudioDiagnostics';
import { supabase } from '../lib/supabase';
import SessionTimer from './SessionTimer';

interface MusicPlayerProps {
  showDiagnostics?: boolean;
  showQueue?: boolean;
}

export function MusicPlayer({ showDiagnostics = false, showQueue = true }: MusicPlayerProps = {}) {
  const {
    activeChannel,
    channelStates,
    playlist,
    currentTrackIndex,
    currentTrack,
    isAdminMode,
    isPlaying,
    audioEngine,
    audioMetrics,
    toggleChannel,
    setChannelEnergy,
    toggleAdminPlayback,
    setAdminPreview,
    skipTrack,
    seek,
    setVolume,
    getVolume,
  } = useMusicPlayer();

  const { channelImages, slideshowImages: contextSlideshowImages, slideshowEnabled, slideshowDuration } = useImageSet();

  const [currentTime, setCurrentTime] = useState(0);
  const [duration, setDuration] = useState(0);
  const [volume, setVolumeState] = useState(0.7);
  const [isQueueExpanded, setIsQueueExpanded] = useState(false);
  const [isPlayerExpanded, setIsPlayerExpanded] = useState(false);
  const [isConsoleExpanded, setIsConsoleExpanded] = useState(false);
  const [manualConsoleControl, setManualConsoleControl] = useState(false);
  const autoCloseTimerRef = useRef<NodeJS.Timeout | null>(null);
  const activeChannelRef = useRef(activeChannel);
  const toggleChannelRef = useRef(toggleChannel);
  const slideshowImages = contextSlideshowImages;
  const [topSlideIndex, setTopSlideIndex] = useState(0);
  const [bottomSlideIndex, setBottomSlideIndex] = useState(1);
  const [isFadingOut, setIsFadingOut] = useState(false);
  const [slideStartTime, setSlideStartTime] = useState(Date.now());

  // Keep refs updated with latest values
  useEffect(() => {
    activeChannelRef.current = activeChannel;
    toggleChannelRef.current = toggleChannel;
  }, [activeChannel, toggleChannel]);

  useEffect(() => {
    if (audioEngine) {
      setVolumeState(getVolume());
    }
  }, [audioEngine]);

  useEffect(() => {
    if (audioEngine) {
      setCurrentTime(audioEngine.getCurrentTime());
      setDuration(audioEngine.getDuration());
    }
  }, [audioEngine, audioMetrics]);

  const handleSeek = (e: React.ChangeEvent<HTMLInputElement>) => {
    const time = parseFloat(e.target.value);
    setCurrentTime(time);
    seek(time);
  };

  const handleVolumeChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const vol = parseFloat(e.target.value);
    setVolumeState(vol);
    setVolume(vol);
  };

  const formatTime = (seconds: number) => {
    if (!seconds || isNaN(seconds)) return '0:00';
    const mins = Math.floor(seconds / 60);
    const secs = Math.floor(seconds % 60);
    return `${mins}:${secs.toString().padStart(2, '0')}`;
  };

  const getChannelImage = (channelId: string, defaultImageUrl: string | null) => {
    return channelImages[channelId] || defaultImageUrl;
  };

  // Create stable callback for timer end using refs
  const handleTimerEnd = useCallback(() => {
    console.error('!!!!! TIMER END CALLBACK EXECUTING !!!!!');
    console.log('⏰ MusicPlayer handleTimerEnd called');
    console.log('⏰ activeChannelRef.current:', activeChannelRef.current);
    console.log('⏰ toggleChannelRef.current:', toggleChannelRef.current);

    if (activeChannelRef.current && toggleChannelRef.current) {
      console.log('⏰ Calling toggleChannel to stop music for channel:', activeChannelRef.current.id);
      toggleChannelRef.current(activeChannelRef.current, false, true);
    } else {
      console.log('⏰ No active channel to stop or toggleChannel not available');
    }
  }, []); // Empty deps - stable callback that uses refs

  // Log when handleTimerEnd changes
  useEffect(() => {
    console.log('⏰ handleTimerEnd callback created/updated, type:', typeof handleTimerEnd, 'function:', handleTimerEnd);
  }, [handleTimerEnd]);

  // Auto-open console when channel changes (mobile only)
  useEffect(() => {
    if (!activeChannel) return;

    // Don't auto-open if user is manually controlling
    if (manualConsoleControl) return;

    // Clear any existing timer
    if (autoCloseTimerRef.current) {
      clearTimeout(autoCloseTimerRef.current);
      autoCloseTimerRef.current = null;
    }

    // Auto-open the console
    setIsConsoleExpanded(true);

    // Auto-close after 5 seconds only if music is playing
    autoCloseTimerRef.current = setTimeout(() => {
      if (!manualConsoleControl && isPlaying) {
        setIsConsoleExpanded(false);
      }
    }, 5000);

    // Cleanup on unmount
    return () => {
      if (autoCloseTimerRef.current) {
        clearTimeout(autoCloseTimerRef.current);
        autoCloseTimerRef.current = null;
      }
    };
  }, [activeChannel?.id, manualConsoleControl, isPlaying]);

  // Handle manual console toggle
  const handleConsoleToggle = () => {
    if (autoCloseTimerRef.current) {
      clearTimeout(autoCloseTimerRef.current);
      autoCloseTimerRef.current = null;
    }

    setManualConsoleControl(true);
    setIsConsoleExpanded(!isConsoleExpanded);

    setTimeout(() => {
      setManualConsoleControl(false);
    }, 15000);
  };

  // Reset slideshow indices when images change
  useEffect(() => {
    if (slideshowImages.length > 0) {
      setTopSlideIndex(0);
      setBottomSlideIndex(1 % slideshowImages.length);
      setIsFadingOut(false);
      setSlideStartTime(Date.now());
    }
  }, [slideshowImages]);

  // Slideshow with crossfade: fade out top image to reveal bottom underneath
  useEffect(() => {
    if (!slideshowEnabled || !isPlayerExpanded || !isPlaying || slideshowImages.length <= 1) {
      setIsFadingOut(false);
      return;
    }

    // Reset fade state when starting
    setIsFadingOut(false);
    setSlideStartTime(Date.now());

    const intervalMs = slideshowDuration * 1000;
    const fadeMs = 2000;

    const timer = setInterval(() => {
      // Start fading out the top image (reveals bottom)
      setIsFadingOut(true);

      // After fade completes, swap the layers
      setTimeout(() => {
        // What was on bottom is now fully visible, move it to top
        setTopSlideIndex(prev => {
          const newTop = bottomSlideIndex;
          // Set new bottom to be next in sequence
          setBottomSlideIndex((bottomSlideIndex + 1) % slideshowImages.length);
          return newTop;
        });
        setIsFadingOut(false);
        setSlideStartTime(Date.now());
      }, fadeMs);
    }, intervalMs);

    return () => {
      clearInterval(timer);
      setIsFadingOut(false);
    };
  }, [slideshowEnabled, isPlayerExpanded, isPlaying, slideshowImages.length, slideshowDuration, bottomSlideIndex]);

  if (isAdminMode && currentTrack) {
    return (
      <>
        {showDiagnostics && audioMetrics && <HTML5AudioDiagnostics metrics={audioMetrics} />}
        <div className="fixed bottom-0 left-0 right-0 bg-white border-t border-slate-200 shadow-lg z-50">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
            <div className="flex items-center gap-4">
              <button
                onClick={toggleAdminPlayback}
                className="w-12 h-12 flex items-center justify-center bg-slate-900 hover:bg-slate-800 text-white rounded-full transition-colors flex-shrink-0 shadow-lg"
              >
                {isPlaying ? <Pause size={22} fill="currentColor" /> : <Play size={22} fill="currentColor" className="ml-0.5" />}
              </button>

              <div className="flex-1 min-w-0">
                <div className="text-xs text-slate-500 mb-1 font-medium uppercase tracking-wide">Admin Preview</div>
                <div className="font-bold text-slate-900 text-base truncate">
                  {currentTrack?.metadata?.track_name || 'Unknown Track'}
                </div>
                <div className="text-xs text-slate-600 flex items-center gap-2 mt-0.5">
                  <span>{currentTrack?.metadata?.artist_name || 'Unknown Artist'}</span>
                  <span className="text-slate-400">•</span>
                  <span className="font-medium">
                    BPM: {currentTrack?.metadata?.bpm || 'N/A'}
                  </span>
                </div>
              </div>

              <div className="flex items-center gap-4 flex-shrink-0">
                <div className="flex flex-col items-center min-w-[300px]">
                  <input
                    type="range"
                    min="0"
                    max={duration || 0}
                    value={currentTime}
                    onChange={handleSeek}
                    className="w-full h-2 bg-slate-200 rounded-lg appearance-none cursor-pointer slider-thumb"
                    style={{
                      background: `linear-gradient(to right, #0f172a 0%, #0f172a ${(currentTime / duration) * 100}%, #e2e8f0 ${(currentTime / duration) * 100}%, #e2e8f0 100%)`
                    }}
                  />
                  <div className="flex justify-between w-full text-xs text-slate-500 mt-1.5 font-medium">
                    <span>{formatTime(currentTime)}</span>
                    <span>{formatTime(duration)}</span>
                  </div>
                </div>

                <div className="flex items-center gap-2">
                  <Volume2 size={18} className="text-slate-600" />
                  <input
                    type="range"
                    min="0"
                    max="1"
                    step="0.01"
                    value={volume}
                    onChange={handleVolumeChange}
                    className="w-24 h-2 bg-slate-200 rounded-lg appearance-none cursor-pointer slider-thumb"
                  />
                </div>

                <button
                  onClick={() => setAdminPreview(null)}
                  className="p-2 rounded-lg bg-slate-100 hover:bg-slate-200 text-slate-600 transition-colors"
                  title="Close preview"
                >
                  <X size={18} />
                </button>
              </div>
            </div>
          </div>
        </div>
      </>
    );
  }

  if (!activeChannel) return null;

  const channelState = channelStates[activeChannel.id];
  const nextTracks = playlist.slice(currentTrackIndex + 1, currentTrackIndex + 11);

  return (
    <>
      {showDiagnostics && audioMetrics && <HTML5AudioDiagnostics metrics={audioMetrics} />}

      {/* Full-Screen Channel Image - Covers everything except top nav and bottom player */}
      {isPlayerExpanded && (
        <div
          className="fixed top-16 bottom-0 left-0 right-0 z-40 overflow-hidden bg-black cursor-pointer"
          onClick={() => setIsPlayerExpanded(false)}
          title="Click to close"
        >
          {slideshowEnabled && slideshowImages.length > 0 ? (
            <div className="relative w-full h-full">
              {/* Bottom image - always at full opacity underneath */}
              <img
                key={`bottom-${bottomSlideIndex}`}
                src={slideshowImages[bottomSlideIndex]}
                alt="Next slide"
                className="absolute inset-0 w-full h-full object-cover"
                style={{ objectPosition: 'center', zIndex: 1 }}
              />

              {/* Top image - fades out to reveal bottom */}
              <img
                key={`top-${topSlideIndex}`}
                src={slideshowImages[topSlideIndex]}
                alt={`Slide ${topSlideIndex + 1}`}
                className="absolute inset-0 w-full h-full object-cover"
                style={{
                  objectPosition: 'center',
                  zIndex: 2,
                  opacity: isFadingOut ? 0 : 1,
                  transition: 'opacity 2s cubic-bezier(0.4, 0.0, 0.2, 1)'
                }}
              />
            </div>
          ) : getChannelImage(activeChannel.id, activeChannel.image_url) ? (
            <img
              src={getChannelImage(activeChannel.id, activeChannel.image_url)!}
              alt={activeChannel.channel_name}
              className="w-full h-full object-cover"
              style={{ objectPosition: 'center' }}
            />
          ) : (
            <div className="w-full h-full bg-gradient-to-br from-slate-200 to-slate-300 flex items-center justify-center">
              <div className="text-center">
                <div className="text-9xl font-bold text-slate-400/30 mb-4">
                  {activeChannel.channel_name.charAt(0).toUpperCase()}
                </div>
                <div className="text-3xl font-bold text-slate-500">
                  {activeChannel.channel_name}
                </div>
              </div>
            </div>
          )}
        </div>
      )}

      <div
        className="hidden md:block fixed bottom-0 left-0 right-0 bg-white border-t border-slate-200 shadow-2xl z-50 overflow-hidden"
      >

        {showQueue && isQueueExpanded && nextTracks.length > 0 && (
          <div className="bg-slate-50 border-b border-slate-200 max-h-96 overflow-y-auto">
            <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
              <div className="mb-3 text-xs font-bold text-slate-700 uppercase tracking-wide">
                Next {nextTracks.length} Track{nextTracks.length !== 1 ? 's' : ''} in Queue
              </div>
              <div className="space-y-2">
                {nextTracks.map((track, index) => (
                  <div
                    key={`${track.metadata?.track_id}-${index}`}
                    className="flex items-center gap-3 p-3 bg-white rounded-xl border border-slate-200 hover:border-slate-300 hover:shadow-sm transition-all"
                  >
                    <div className="w-7 h-7 flex items-center justify-center bg-slate-900 text-white text-xs font-bold rounded-lg flex-shrink-0">
                      {index + 1}
                    </div>
                    <div className="flex-1 min-w-0">
                      <div className="text-sm font-bold text-slate-900 truncate">
                        {track.metadata?.track_name || 'Unknown Track'}
                      </div>
                      <div className="text-xs text-slate-600 truncate mt-0.5">
                        {track.metadata?.artist_name || 'Unknown Artist'}
                      </div>
                    </div>
                    <div className="text-xs text-slate-500 flex-shrink-0 font-medium">
                      BPM: {track.metadata?.bpm || 'N/A'}
                    </div>
                    <div className="text-xs font-mono text-slate-400 flex-shrink-0">
                      {track.metadata?.track_id}
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}

        {/* Desktop Layout */}
        <div className="hidden md:block py-4">
          <div className="relative flex items-center max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            {/* Left: Track Info */}
            <div className="flex-1 min-w-0 pr-4">
              <div className="font-bold text-slate-900 text-lg truncate leading-tight">
                {currentTrack?.metadata?.track_name || 'No Track Playing'}
              </div>
              <div className="text-sm text-slate-600 truncate mt-1">
                {currentTrack?.metadata?.artist_name || activeChannel.channel_name}
              </div>
              <div className="text-xs text-slate-500 flex items-center gap-2 mt-1">
                <span className="font-medium">
                  BPM: {currentTrack?.metadata?.bpm || 'N/A'}
                </span>
                <span className="text-slate-400">•</span>
                <span className="font-mono text-slate-400">
                  ID: {currentTrack?.metadata?.track_id || 'N/A'}
                </span>
                <span className="text-slate-400">•</span>
                <span className="font-medium">
                  {currentTrackIndex + 1} / {playlist.length}
                </span>
              </div>
            </div>

            {/* Center: Music Player Controls - Absolutely positioned to center play button */}
            <div className="absolute left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2 flex items-center gap-3">
              <SessionTimer
                isPlaying={isPlaying}
                onTimerEnd={handleTimerEnd}
              />
              <button
                onClick={() => toggleChannel(activeChannel, !channelState?.isOn, true)}
                className={`w-14 h-14 flex items-center justify-center rounded-full transition-all flex-shrink-0 shadow-lg ${
                  channelState?.isOn
                    ? 'bg-slate-900 hover:bg-slate-800 text-white'
                    : 'bg-slate-200 hover:bg-slate-300 text-slate-700'
                }`}
              >
                {channelState?.isOn ? (
                  <Pause size={24} fill="currentColor" />
                ) : (
                  <Play size={24} fill="currentColor" className="ml-0.5" />
                )}
              </button>
              <button
                onClick={skipTrack}
                disabled={!channelState?.isOn || playlist.length === 0}
                className="w-10 h-10 flex items-center justify-center rounded-full bg-slate-100 hover:bg-slate-200 text-slate-700 transition-colors disabled:opacity-50 disabled:cursor-not-allowed border border-slate-200 shadow-sm"
                title="Skip track"
              >
                <SkipForward size={18} />
              </button>
            </div>

            {/* Right: Energy Level Selector and Controls */}
            <div className="flex items-center justify-end gap-3 flex-1 pl-4">
              {/* Energy Level Selector */}
              <div className="flex gap-2 bg-slate-100 rounded-xl p-1.5 shadow-sm border border-slate-200">
                <button
                  onClick={() => setChannelEnergy(activeChannel.id, 'low')}
                  className={`px-5 py-2.5 rounded-lg text-sm font-bold uppercase tracking-wide transition-all ${
                    channelState?.energyLevel === 'low'
                      ? 'bg-blue-600 text-white shadow-md'
                      : 'text-slate-600 hover:bg-white hover:shadow-sm'
                  }`}
                >
                  Low
                </button>
                <button
                  onClick={() => setChannelEnergy(activeChannel.id, 'medium')}
                  className={`px-5 py-2.5 rounded-lg text-sm font-bold uppercase tracking-wide transition-all ${
                    channelState?.energyLevel === 'medium'
                      ? 'bg-orange-600 text-white shadow-md'
                      : 'text-slate-600 hover:bg-white hover:shadow-sm'
                  }`}
                >
                  Medium
                </button>
                <button
                  onClick={() => setChannelEnergy(activeChannel.id, 'high')}
                  className={`px-5 py-2.5 rounded-lg text-sm font-bold uppercase tracking-wide transition-all ${
                    channelState?.energyLevel === 'high'
                      ? 'bg-red-600 text-white shadow-md'
                      : 'text-slate-600 hover:bg-white hover:shadow-sm'
                  }`}
                >
                  High
                </button>
              </div>

              {/* Additional Controls */}
              <div className="flex items-center gap-2">
                <button
                  onClick={() => setIsPlayerExpanded(!isPlayerExpanded)}
                  className="p-2.5 rounded-lg bg-slate-100 hover:bg-slate-200 text-slate-700 transition-colors border border-slate-200"
                  title={isPlayerExpanded ? 'Exit fullscreen' : 'Fullscreen'}
                >
                  {isPlayerExpanded ? <Minimize2 size={18} /> : <Maximize2 size={18} />}
                </button>
                {showQueue && (
                  <button
                    onClick={() => setIsQueueExpanded(!isQueueExpanded)}
                    className="px-4 py-2.5 rounded-lg bg-slate-100 hover:bg-slate-200 text-slate-700 font-medium text-sm transition-colors flex items-center gap-2 border border-slate-200"
                    title={isQueueExpanded ? 'Hide queue' : 'Show queue'}
                  >
                    {isQueueExpanded ? <ChevronDown size={16} /> : <ChevronUp size={16} />}
                    <span className="font-bold">Queue</span>
                  </button>
                )}
              </div>
            </div>
          </div>
        </div>


        {/* Mobile Layout - Hidden (controls now on channel card) */}
        <div className="hidden">
        </div>
      </div>
    </>
  );
}
