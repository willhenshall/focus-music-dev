/**
 * HTML5 Audio Engine
 * Industry-standard audio playback for iOS compatibility
 * Supports background playback, lock screen controls, and silent mode
 */

type TrackLoadCallback = (trackId: string, duration: number) => void;
type TrackEndCallback = () => void;
type DiagnosticsUpdateCallback = (metrics: AudioMetrics) => void;

export interface AudioMetrics {
  currentTrackId: string | null;
  currentTrackUrl: string | null;
  loadStartTime: number;
  loadEndTime: number;
  loadDuration: number;
  networkState: number;
  networkStateLabel: string;
  readyState: number;
  readyStateLabel: string;
  playbackState: 'idle' | 'loading' | 'ready' | 'playing' | 'paused' | 'stopped';
  currentTime: number;
  duration: number;
  buffered: number;
  bufferPercentage: number;
  volume: number;
  muted: boolean;
  playbackRate: number;
  error: string | null;
  isStalled: boolean;
  isWaiting: boolean;
  canPlayThrough: boolean;
  mediaSessionActive: boolean;
  silentSwitchWorkaround: boolean;
  audioElement: 'primary' | 'secondary' | null;
}

export class HTML5AudioEngine {
  private primaryAudio: HTMLAudioElement;
  private secondaryAudio: HTMLAudioElement;
  private currentAudio: HTMLAudioElement;
  private nextAudio: HTMLAudioElement;
  private currentTrackId: string | null = null;
  private volume: number = 0.7;
  private isPlayingState: boolean = false;
  private crossfadeDuration: number = 1000; // 1 second crossfade
  private enableCrossfade: boolean = true; // Can be disabled for admin preview mode

  // Callbacks
  private onTrackLoad: TrackLoadCallback | null = null;
  private onTrackEnd: TrackEndCallback | null = null;
  private onDiagnosticsUpdate: DiagnosticsUpdateCallback | null = null;

  // Metrics
  private metrics: AudioMetrics = {
    currentTrackId: null,
    currentTrackUrl: null,
    loadStartTime: 0,
    loadEndTime: 0,
    loadDuration: 0,
    networkState: 0,
    networkStateLabel: 'NETWORK_EMPTY',
    readyState: 0,
    readyStateLabel: 'HAVE_NOTHING',
    playbackState: 'idle',
    currentTime: 0,
    duration: 0,
    buffered: 0,
    bufferPercentage: 0,
    volume: 0.7,
    muted: false,
    playbackRate: 1.0,
    error: null,
    isStalled: false,
    isWaiting: false,
    canPlayThrough: false,
    mediaSessionActive: false,
    silentSwitchWorkaround: true,
    audioElement: null,
  };

  // Animation frame for metrics updates
  private metricsUpdateFrame: number | null = null;

  constructor() {
    // Create two audio elements for crossfading
    this.primaryAudio = this.createAudioElement();
    this.secondaryAudio = this.createAudioElement();

    this.currentAudio = this.primaryAudio;
    this.nextAudio = this.secondaryAudio;

    // Set initial volume
    this.primaryAudio.volume = this.volume;
    this.secondaryAudio.volume = 0;

    // Start metrics update loop
    this.startMetricsLoop();

    // Initialize MediaSession API for lock screen controls
    this.initializeMediaSession();
  }

  private createAudioElement(): HTMLAudioElement {
    const audio = new Audio();
    audio.preload = 'auto';
    audio.crossOrigin = 'anonymous';

    // iOS-specific attributes for background playback
    audio.setAttribute('playsinline', 'true');

    // Event listeners
    audio.addEventListener('canplaythrough', () => {
      this.metrics.error = null; // Clear errors when track loads successfully
      this.updateMetrics();
    });
    audio.addEventListener('loadedmetadata', () => this.updateMetrics());
    audio.addEventListener('loadeddata', () => this.updateMetrics());
    audio.addEventListener('progress', () => this.updateMetrics());
    audio.addEventListener('timeupdate', () => this.updateMetrics());
    audio.addEventListener('waiting', () => {
      this.metrics.isWaiting = true;
      this.updateMetrics();
    });
    audio.addEventListener('playing', () => {
      this.metrics.isWaiting = false;
      this.metrics.error = null; // Clear any spurious errors once playing
      this.updateMetrics();
    });
    audio.addEventListener('stalled', () => {
      this.metrics.isStalled = true;
      this.updateMetrics();
    });
    audio.addEventListener('error', (e) => {
      // Only log errors if readyState indicates actual failure
      // HTML5 Audio sometimes fires spurious error events during normal operation
      if (audio.readyState === 0 && audio.networkState === 3) {
        const error = audio.error;
        let errorMessage = 'Unknown error';

        if (error) {
          switch (error.code) {
            case error.MEDIA_ERR_ABORTED:
              errorMessage = 'MEDIA_ERR_ABORTED: Playback aborted';
              break;
            case error.MEDIA_ERR_NETWORK:
              errorMessage = 'MEDIA_ERR_NETWORK: Network error';
              break;
            case error.MEDIA_ERR_DECODE:
              errorMessage = 'MEDIA_ERR_DECODE: Decode error';
              break;
            case error.MEDIA_ERR_SRC_NOT_SUPPORTED:
              errorMessage = 'MEDIA_ERR_SRC_NOT_SUPPORTED: Source not supported';
              break;
          }
        }

        this.metrics.error = errorMessage;
        console.error('[HTML5Audio] Error:', errorMessage, e);
        this.updateMetrics();
      }
    });

    return audio;
  }

  private initializeMediaSession() {
    if ('mediaSession' in navigator) {
      this.metrics.mediaSessionActive = true;

      // Set up action handlers for lock screen controls
      navigator.mediaSession.setActionHandler('play', () => {
        this.play();
      });

      navigator.mediaSession.setActionHandler('pause', () => {
        this.pause();
      });

      navigator.mediaSession.setActionHandler('nexttrack', () => {
        if (this.onTrackEnd) {
          this.onTrackEnd();
        }
      });

      navigator.mediaSession.setActionHandler('seekto', (details) => {
        if (details.seekTime !== undefined) {
          this.seek(details.seekTime);
        }
      });
    }
  }

  private updateMediaSessionMetadata(trackName?: string, artistName?: string) {
    if ('mediaSession' in navigator && trackName) {
      navigator.mediaSession.metadata = new MediaMetadata({
        title: trackName,
        artist: artistName || 'focus.music',
        album: 'Focus Music',
      });
    }
  }

  private getNetworkStateLabel(state: number): string {
    const labels = ['NETWORK_EMPTY', 'NETWORK_IDLE', 'NETWORK_LOADING', 'NETWORK_NO_SOURCE'];
    return labels[state] || 'UNKNOWN';
  }

  private getReadyStateLabel(state: number): string {
    const labels = ['HAVE_NOTHING', 'HAVE_METADATA', 'HAVE_CURRENT_DATA', 'HAVE_FUTURE_DATA', 'HAVE_ENOUGH_DATA'];
    return labels[state] || 'UNKNOWN';
  }

  private startMetricsLoop() {
    const updateLoop = () => {
      this.updateMetrics();
      this.metricsUpdateFrame = requestAnimationFrame(updateLoop);
    };
    updateLoop();
  }

  private updateMetrics() {
    const audio = this.currentAudio;

    this.metrics.networkState = audio.networkState;
    this.metrics.networkStateLabel = this.getNetworkStateLabel(audio.networkState);
    this.metrics.readyState = audio.readyState;
    this.metrics.readyStateLabel = this.getReadyStateLabel(audio.readyState);
    this.metrics.currentTime = audio.currentTime;
    this.metrics.duration = audio.duration || 0;
    this.metrics.volume = this.volume;
    this.metrics.muted = audio.muted;
    this.metrics.playbackRate = audio.playbackRate;
    this.metrics.canPlayThrough = audio.readyState >= 4;
    this.metrics.audioElement = audio === this.primaryAudio ? 'primary' : 'secondary';

    // Calculate buffered percentage
    if (audio.buffered.length > 0 && audio.duration) {
      const bufferedEnd = audio.buffered.end(audio.buffered.length - 1);
      this.metrics.buffered = bufferedEnd;
      this.metrics.bufferPercentage = (bufferedEnd / audio.duration) * 100;
    } else {
      this.metrics.buffered = 0;
      this.metrics.bufferPercentage = 0;
    }

    if (this.onDiagnosticsUpdate) {
      this.onDiagnosticsUpdate({ ...this.metrics });
    }
  }

  setCallbacks(callbacks: {
    onTrackLoad?: TrackLoadCallback;
    onTrackEnd?: TrackEndCallback;
    onDiagnosticsUpdate?: DiagnosticsUpdateCallback;
  }) {
    if (callbacks.onTrackLoad) this.onTrackLoad = callbacks.onTrackLoad;
    if (callbacks.onTrackEnd) this.onTrackEnd = callbacks.onTrackEnd;
    if (callbacks.onDiagnosticsUpdate) this.onDiagnosticsUpdate = callbacks.onDiagnosticsUpdate;
  }

  setCrossfadeEnabled(enabled: boolean): void {
    this.enableCrossfade = enabled;
  }

  async loadTrack(trackId: string, url: string, metadata?: { trackName?: string; artistName?: string }): Promise<void> {
    this.metrics.loadStartTime = performance.now();
    this.metrics.playbackState = 'loading';
    this.metrics.error = null;
    this.currentTrackId = trackId;
    this.metrics.currentTrackUrl = url;

    // Load into the next audio element for smooth transitions
    this.nextAudio.src = url;
    this.nextAudio.load();

    // Update MediaSession metadata
    if (metadata) {
      this.updateMediaSessionMetadata(metadata.trackName, metadata.artistName);
    }

    return new Promise((resolve, reject) => {
      const timeout = setTimeout(() => {
        cleanup();
        this.metrics.error = 'Load timeout: Track took too long to load';
        this.metrics.playbackState = 'idle';
        this.updateMetrics();
        reject(new Error('Track load timeout after 30 seconds'));
      }, 30000);

      const onCanPlay = () => {
        clearTimeout(timeout);
        this.metrics.loadEndTime = performance.now();
        this.metrics.loadDuration = this.metrics.loadEndTime - this.metrics.loadStartTime;
        this.metrics.currentTrackId = trackId;
        this.metrics.playbackState = 'ready';
        this.metrics.error = null;

        cleanup();

        if (this.onTrackLoad) {
          this.onTrackLoad(trackId, this.nextAudio.duration);
        }

        resolve();
      };

      const onError = (e: Event) => {
        clearTimeout(timeout);
        cleanup();

        const errorMsg = this.metrics.error || 'Unknown error loading track';
        this.metrics.playbackState = 'idle';
        this.updateMetrics();

        console.error(`[HTML5Audio] Failed to load track ${trackId}:`, errorMsg);
        reject(new Error(`Failed to load track ${trackId}: ${errorMsg}`));
      };

      const cleanup = () => {
        this.nextAudio.removeEventListener('canplaythrough', onCanPlay);
        this.nextAudio.removeEventListener('error', onError);
      };

      this.nextAudio.addEventListener('canplaythrough', onCanPlay, { once: true });
      this.nextAudio.addEventListener('error', onError, { once: true });

      // Set up ended callback
      this.nextAudio.onended = () => {
        if (this.isPlayingState && this.onTrackEnd) {
          this.onTrackEnd();
        }
      };
    });
  }

  async play(): Promise<void> {
    if (!this.nextAudio.src && !this.currentAudio.src) {
      console.warn('[HTML5Audio] No track loaded');
      return;
    }

    // If we have a new track loaded in nextAudio (different from currentAudio), crossfade to it
    // Check both that nextAudio has a source AND that it's different from currentAudio's source
    const hasNewTrack = this.nextAudio.src &&
                        this.nextAudio.src !== this.currentAudio.src &&
                        this.nextAudio !== this.currentAudio;

    if (hasNewTrack) {
      await this.crossfadeToNext();
    } else {
      // Just resume current track
      try {
        await this.currentAudio.play();
        this.isPlayingState = true;
        this.metrics.playbackState = 'playing';
        this.updateMetrics();
      } catch (error) {
        console.error('[HTML5Audio] Play error:', error);
        this.metrics.error = `Play failed: ${error}`;
        this.updateMetrics();
        throw error;
      }
    }
  }

  private async crossfadeToNext(): Promise<void> {
    const oldAudio = this.currentAudio;
    const newAudio = this.nextAudio;

    // If there's no previous track playing (e.g., admin mode start), just play immediately
    const hasOldTrack = oldAudio.src && oldAudio.duration > 0;

    // If crossfade is disabled (admin preview mode), always play immediately
    if (!hasOldTrack || !this.enableCrossfade) {
      // Stop old track if exists
      if (hasOldTrack) {
        oldAudio.pause();
        oldAudio.currentTime = 0;
      }

      // No crossfade, just start the new track at full volume
      newAudio.volume = this.volume;
      try {
        await newAudio.play();
        // Immediately swap references
        this.currentAudio = newAudio;
        this.nextAudio = oldAudio;
        this.isPlayingState = true;
        this.metrics.playbackState = 'playing';
        this.updateMetrics();
      } catch (error) {
        console.error('[HTML5Audio] Failed to start track:', error);
        throw error;
      }
      return;
    }

    // Start new track at volume 0
    newAudio.volume = 0;

    try {
      await newAudio.play();
    } catch (error) {
      console.error('[HTML5Audio] Failed to start next track:', error);
      throw error;
    }

    // Set playing state immediately when crossfade starts
    this.isPlayingState = true;
    this.metrics.playbackState = 'playing';

    // Crossfade
    const startTime = performance.now();
    const fadeInterval = 50; // Update every 50ms
    const steps = this.crossfadeDuration / fadeInterval;
    let step = 0;

    const fade = setInterval(() => {
      step++;
      const progress = Math.min(step / steps, 1);

      // Ease-in-out curve
      const eased = progress < 0.5
        ? 2 * progress * progress
        : 1 - Math.pow(-2 * progress + 2, 2) / 2;

      oldAudio.volume = this.volume * (1 - eased);
      newAudio.volume = this.volume * eased;

      if (progress >= 1) {
        clearInterval(fade);
        oldAudio.pause();
        oldAudio.currentTime = 0;
        oldAudio.src = '';

        // Swap references
        this.currentAudio = newAudio;
        this.nextAudio = oldAudio;

        this.updateMetrics();
      }
    }, fadeInterval);
  }

  pause(): void {
    this.currentAudio.pause();
    this.isPlayingState = false;
    this.metrics.playbackState = 'paused';
    this.updateMetrics();
  }

  stop(): void {
    this.currentAudio.pause();
    this.currentAudio.currentTime = 0;
    this.isPlayingState = false;
    this.metrics.playbackState = 'stopped';
    this.updateMetrics();
  }

  seek(time: number): void {
    if (this.currentAudio.duration) {
      this.currentAudio.currentTime = Math.max(0, Math.min(time, this.currentAudio.duration));
      this.updateMetrics();
    }
  }

  setVolume(value: number): void {
    this.volume = Math.max(0, Math.min(1, value));
    this.currentAudio.volume = this.volume;
    this.updateMetrics();
  }

  getVolume(): number {
    return this.volume;
  }

  getCurrentTime(): number {
    return this.currentAudio.currentTime;
  }

  getDuration(): number {
    return this.currentAudio.duration || 0;
  }

  isPlaying(): boolean {
    return this.isPlayingState && !this.currentAudio.paused;
  }

  getMetrics(): AudioMetrics {
    return { ...this.metrics };
  }

  destroy(): void {
    if (this.metricsUpdateFrame) {
      cancelAnimationFrame(this.metricsUpdateFrame);
    }

    this.stop();
    this.primaryAudio.src = '';
    this.secondaryAudio.src = '';
    this.primaryAudio.load();
    this.secondaryAudio.load();

    // Clear MediaSession
    if ('mediaSession' in navigator) {
      navigator.mediaSession.setActionHandler('play', null);
      navigator.mediaSession.setActionHandler('pause', null);
      navigator.mediaSession.setActionHandler('nexttrack', null);
      navigator.mediaSession.setActionHandler('seekto', null);
    }
  }
}
