import { createClient } from '@supabase/supabase-js';
import * as dotenv from 'dotenv';

dotenv.config();

const supabaseUrl = process.env.VITE_SUPABASE_URL!;
const supabaseServiceKey = process.env.VITE_SUPABASE_SERVICE_ROLE_KEY!;

const supabase = createClient(supabaseUrl, supabaseServiceKey, {
  auth: {
    persistSession: false,
    autoRefreshToken: false,
  },
});

async function updateAllMetadata() {
  console.log('🎵 Updating all track metadata from sidecar files...\n');

  const batchSize = 50;
  let offset = 0;
  let totalProcessed = 0;
  let totalSuccess = 0;
  let totalErrors = 0;

  while (true) {
    console.log(`\n📦 Processing batch starting at offset ${offset}...`);

    const { data: tracks, error: fetchError } = await supabase
      .from('audio_tracks')
      .select('id, metadata')
      .not('metadata->track_id', 'is', null)
      .range(offset, offset + batchSize - 1);

    if (fetchError) {
      console.error('Error fetching tracks:', fetchError);
      break;
    }

    if (!tracks || tracks.length === 0) {
      console.log('✅ No more tracks to process');
      break;
    }

    console.log(`   Found ${tracks.length} tracks to update`);

    for (const track of tracks) {
      const trackId = track.metadata?.track_id;

      if (!trackId) {
        totalErrors++;
        continue;
      }

      try {
        const { data, error } = await supabase.rpc('update_single_track_metadata', {
          track_uuid: track.id,
          track_id_param: trackId
        });

        if (error) {
          console.error(`   ❌ Error updating track ${trackId}:`, error.message);
          totalErrors++;
        } else if (data) {
          totalSuccess++;
        } else {
          totalErrors++;
        }

        totalProcessed++;
      } catch (e: any) {
        console.error(`   ❌ Exception updating track ${trackId}:`, e.message);
        totalErrors++;
        totalProcessed++;
      }
    }

    console.log(`   Progress: ${totalProcessed} processed, ${totalSuccess} updated, ${totalErrors} errors`);

    offset += batchSize;

    if (tracks.length < batchSize) {
      break;
    }
  }

  console.log('\n🎉 Metadata update complete!');
  console.log(`   Total processed: ${totalProcessed}`);
  console.log(`   Total updated: ${totalSuccess}`);
  console.log(`   Total errors: ${totalErrors}`);
}

updateAllMetadata().catch(console.error);
