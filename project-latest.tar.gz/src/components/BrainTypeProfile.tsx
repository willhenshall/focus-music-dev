import { useState, useEffect, useRef } from 'react';
import { Play, Pause } from 'lucide-react';
import { BrainType, BrainTypeContent, getBrainTypeContent, getAllBrainTypeComparison } from '../lib/brainTypeCalculator';
import { CognitiveProfiles } from './CognitiveProfiles';
import { AudioTrack } from '../lib/supabase';
import { getPreviewTracks } from '../lib/previewService';

type Channel = {
  id: string;
  channel_name: string;
  image_url: string | null;
  description: string | null;
};

type BrainTypeProfileProps = {
  primaryType: BrainType;
  secondaryType?: BrainType;
  secondaryScore?: number;
  channels?: Channel[];
  adhdIndicator?: number;
  asdScore?: number;
  stimulantLevel?: string;
  onSignUp?: () => void;
};

export function BrainTypeProfile({ primaryType, secondaryType, secondaryScore, channels, adhdIndicator, asdScore, stimulantLevel, onSignUp }: BrainTypeProfileProps) {
  const content = getBrainTypeContent(primaryType);
  const secondaryContent = secondaryType ? getBrainTypeContent(secondaryType) : null;
  const comparison = getAllBrainTypeComparison();

  const [previewTracks, setPreviewTracks] = useState<Record<string, AudioTrack>>({});
  const [playingChannelId, setPlayingChannelId] = useState<string | null>(null);
  const [loading, setLoading] = useState<Record<string, boolean>>({});
  const audioRef = useRef<HTMLAudioElement | null>(null);

  useEffect(() => {
    if (channels && channels.length > 0) {
      loadPreviewTracks();
    }
    return () => {
      if (audioRef.current) {
        audioRef.current.pause();
        audioRef.current = null;
      }
    };
  }, [channels]);

  const loadPreviewTracks = async () => {
    if (!channels) return;
    const channelIds = channels.map(ch => ch.id);
    console.log('Loading preview tracks for channels:', channelIds);
    const tracks = await getPreviewTracks(channelIds);
    console.log('Loaded preview tracks:', tracks);
    setPreviewTracks(tracks);
  };

  const handlePreviewToggle = async (channelId: string) => {
    const track = previewTracks[channelId];
    if (!track) {
      alert('No preview track available for this channel yet.');
      return;
    }

    if (playingChannelId === channelId) {
      if (audioRef.current) {
        audioRef.current.pause();
        audioRef.current = null;
      }
      setPlayingChannelId(null);
      return;
    }

    if (audioRef.current) {
      audioRef.current.pause();
    }

    setLoading({ ...loading, [channelId]: true });

    // Check if file_path is already a full URL or just a path
    const audioUrl = track.file_path.startsWith('http')
      ? track.file_path
      : `${import.meta.env.VITE_SUPABASE_URL}/storage/v1/object/public/audio-files/${track.file_path}`;

    console.log('Loading preview track:', audioUrl);

    const audio = new Audio(audioUrl);

    audio.oncanplaythrough = () => {
      setLoading({ ...loading, [channelId]: false });
      audio.play().catch(err => {
        console.error('Error playing audio:', err);
        alert('Failed to play preview track.');
        setPlayingChannelId(null);
      });
      setPlayingChannelId(channelId);
    };

    audio.onerror = (e) => {
      console.error('Audio error:', e);
      setLoading({ ...loading, [channelId]: false });
      alert('Failed to load preview track. The audio file may not be accessible.');
    };

    audio.onended = () => {
      setPlayingChannelId(null);
    };

    audioRef.current = audio;
  };

  const getSecondaryText = (score?: number) => {
    if (!score) return 'You also show some qualities of';
    if (score >= 0.7) return 'You also show qualities of';
    if (score >= 0.55) return 'You also show some qualities of';
    return 'You also show light qualities of';
  };

  const getArticle = (typeName: string) => {
    const vowels = ['a', 'e', 'i', 'o', 'u'];
    return vowels.includes(typeName.toLowerCase()[0]) ? 'an' : 'a';
  };

  const secondaryText = secondaryType ? getSecondaryText(secondaryScore) : null;

  console.log('🧠 BrainTypeProfile rendering:', {
    primaryType,
    secondaryType,
    secondaryScore,
    hasSecondaryContent: !!secondaryContent,
    secondaryText,
    willShowText: !!secondaryContent
  });

  return (
    <div className="space-y-8">
      <div className="bg-white rounded-2xl shadow-lg p-8 border border-slate-200">
        <div className="flex items-start gap-4 mb-6">
          <div className="text-6xl">{content.emoji}</div>
          <div className="flex-1">
            <div className="text-sm font-semibold text-blue-600 uppercase tracking-wide mb-2">
              Your Focus Profile Brain Type
            </div>
            <h2 className="text-3xl font-bold text-slate-900 mb-2">
              {content.headline}
            </h2>
          </div>
        </div>

        <div className="prose prose-slate max-w-none">
          <p className="text-sm text-slate-700 leading-relaxed mb-6">
            {content.body}
            {secondaryContent && onSignUp ? (
              <span>
                {' '}<button onClick={onSignUp} className="text-blue-600 hover:text-blue-700 underline font-medium">More info...</button>
              </span>
            ) : secondaryContent && secondaryText ? (
              <span className="text-slate-600">
                {' '}{secondaryText} {getArticle(secondaryContent.title)} {secondaryContent.title} Type: {secondaryContent.body.split('.')[0]}.
              </span>
            ) : null}
          </p>


          <div className="bg-blue-50 rounded-xl p-6 mb-6 border border-blue-100">
            <h3 className="text-lg font-semibold text-slate-900 mb-3 flex items-center gap-2">
              <span className="text-2xl">🎵</span>
              How focus.music Helps:
            </h3>
            <p className="text-sm text-slate-700 leading-relaxed">
              {content.howItHelps}
            </p>
          </div>

          <div className="bg-slate-50 rounded-xl p-6 border border-slate-200">
            <h3 className="text-lg font-semibold text-slate-900 mb-4">
              Tips for You:
            </h3>
            <ul className="space-y-3">
              {content.tips.map((tip, index) => (
                <li key={index} className="flex items-start gap-3">
                  <span className="flex-shrink-0 w-6 h-6 bg-blue-600 text-white rounded-full flex items-center justify-center text-sm font-semibold mt-0.5">
                    {index + 1}
                  </span>
                  <span className="text-sm text-slate-700 leading-relaxed">{tip}</span>
                </li>
              ))}
            </ul>
          </div>
        </div>
      </div>

      {adhdIndicator !== undefined && asdScore !== undefined && stimulantLevel && (
        <CognitiveProfiles
          adhdIndicator={adhdIndicator}
          asdScore={asdScore}
          stimulantLevel={stimulantLevel}
          onSignUp={onSignUp}
        />
      )}

      <div className="bg-white rounded-2xl shadow-lg p-8 border border-slate-200">
        <div className="text-center mb-6">
          <h3 className="text-2xl font-bold text-slate-900 mb-2">
            Focus Brain Types — At a Glance
          </h3>
          <p className="text-sm text-slate-600">
            Here's how your focus style compares with others — every profile has strengths and challenges, and focus.music tunes in to yours.{secondaryContent ? " Your secondary trait is also highlighted below." : ""}
          </p>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse">
            <thead>
              <tr className="border-b-2 border-slate-200">
                <th className="py-3 px-4 text-sm font-semibold text-slate-700">Brain Type</th>
                <th className="py-3 px-4 text-sm font-semibold text-slate-700">Core Strength</th>
                <th className="py-3 px-4 text-sm font-semibold text-slate-700">Biggest Challenge</th>
                <th className="py-3 px-4 text-sm font-semibold text-slate-700">How Focus Music Helps</th>
              </tr>
            </thead>
            <tbody>
              {comparison.map((type, index) => {
                const isPrimary = type.type === primaryType;
                const isSecondary = type.type === secondaryType;
                return (
                  <tr
                    key={type.type}
                    className={`border-b border-slate-100 transition-colors ${
                      isPrimary
                        ? 'bg-blue-50 font-medium'
                        : isSecondary
                        ? 'bg-slate-50'
                        : 'hover:bg-slate-50'
                    }`}
                  >
                    <td className="py-4 px-4">
                      <div className="flex items-center gap-2">
                        <span className="text-2xl">{type.emoji}</span>
                        <div>
                          <div className="font-semibold text-slate-900">
                            {type.title}
                            {isPrimary && (
                              <span className="ml-2 text-xs bg-blue-600 text-white px-2 py-0.5 rounded-full">
                                You
                              </span>
                            )}
                            {isSecondary && (
                              <span className="ml-2 text-xs bg-slate-400 text-white px-2 py-0.5 rounded-full">
                                Secondary
                              </span>
                            )}
                          </div>
                        </div>
                      </div>
                    </td>
                    <td className="py-4 px-4 text-sm text-slate-700">
                      {type.coreStrength}
                    </td>
                    <td className="py-4 px-4 text-sm text-slate-700">
                      {type.biggestChallenge}
                    </td>
                    <td className="py-4 px-4 text-sm text-slate-700">
                      {type.howFocusHelps}
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
