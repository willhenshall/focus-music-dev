import { useState } from 'react';
import { X, Upload, Loader } from 'lucide-react';
import { supabase, AudioChannel } from '../lib/supabase';

interface TrackUploadModalProps {
  onClose: () => void;
  onSuccess: () => void;
  channels: AudioChannel[];
}

export function TrackUploadModal({ onClose, onSuccess, channels }: TrackUploadModalProps) {
  const [uploading, setUploading] = useState(false);
  const [audioFile, setAudioFile] = useState<File | null>(null);
  const [formData, setFormData] = useState({
    track_id: '',
    track_name: '',
    artist_name: '',
    album_name: '',
    genre_category: '',
    tempo: '',
    bpm: '',
    energy_level: 'medium' as 'low' | 'medium' | 'high',
    source: '',
    file_id: '',
    track_number: '',
    duration: '',
  });
  const [selectedChannels, setSelectedChannels] = useState<string[]>([]);
  const [skipChannelAssignment, setSkipChannelAssignment] = useState(false);

  const handleFileChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      const file = e.target.files[0];
      setAudioFile(file);

      if (!formData.track_name) {
        const fileName = file.name.replace(/\.[^/.]+$/, '');
        setFormData(prev => ({ ...prev, track_name: fileName }));
      }

      const audio = new Audio();
      const objectUrl = URL.createObjectURL(file);
      audio.src = objectUrl;

      audio.addEventListener('loadedmetadata', () => {
        const durationSeconds = Math.round(audio.duration);
        setFormData(prev => ({ ...prev, duration: durationSeconds.toString() }));
        URL.revokeObjectURL(objectUrl);
      });
    }
  };

  const handleInputChange = (field: string, value: string) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  };

  const toggleChannel = (channelId: string) => {
    setSelectedChannels(prev =>
      prev.includes(channelId)
        ? prev.filter(id => id !== channelId)
        : [...prev, channelId]
    );
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    if (!audioFile) {
      alert('Please select an audio file');
      return;
    }

    if (!formData.track_name) {
      alert('Please enter a track name');
      return;
    }

    if (!skipChannelAssignment && selectedChannels.length === 0) {
      alert('Please select at least one channel or check "Skip channel assignment"');
      return;
    }

    setUploading(true);

    try {
      const trackId = formData.track_id || `track_${Date.now()}`;
      const fileExt = audioFile.name.split('.').pop();
      const fileName = `${trackId}.${fileExt}`;

      const { error: uploadError } = await supabase.storage
        .from('audio-files')
        .upload(fileName, audioFile, {
          cacheControl: '3600',
          upsert: false,
        });

      if (uploadError) throw uploadError;

      const { data: { publicUrl } } = supabase.storage
        .from('audio-files')
        .getPublicUrl(fileName);

      const metadata = {
        track_id: trackId,
        track_name: formData.track_name,
        artist_name: formData.artist_name || 'Unknown Artist',
        album_name: formData.album_name || '',
        genre_category: formData.genre_category || '',
        tempo: formData.tempo || '',
        bpm: formData.bpm || '',
        source: formData.source || '',
        file_id: formData.file_id || '',
        track_number: formData.track_number || '',
        duration: formData.duration || '',
        file_size: audioFile.size.toString(),
        mimetype: audioFile.type,
      };

      if (skipChannelAssignment) {
        const { error: insertError } = await supabase
          .from('audio_tracks')
          .insert({
            channel_id: null,
            file_path: publicUrl,
            energy_level: formData.energy_level,
            duration_seconds: formData.duration ? parseFloat(formData.duration) : 0,
            metadata,
          });

        if (insertError) throw insertError;
      } else {
        const trackRecords = selectedChannels.map(channelId => ({
          channel_id: channelId,
          file_path: publicUrl,
          energy_level: formData.energy_level,
          duration_seconds: formData.duration ? parseFloat(formData.duration) : 0,
          metadata,
        }));

        const { error: insertError } = await supabase
          .from('audio_tracks')
          .insert(trackRecords);

        if (insertError) throw insertError;
      }

      const sidecarData = JSON.stringify(metadata, null, 2);
      const sidecarBlob = new Blob([sidecarData], { type: 'application/json' });

      await supabase.storage
        .from('audio-sidecars')
        .upload(`${trackId}.json`, sidecarBlob, {
          cacheControl: '3600',
          upsert: true,
        });

      alert('Track uploaded successfully!');
      onSuccess();
      onClose();
    } catch (error: any) {
      console.error('Upload error:', error);
      alert(`Upload failed: ${error.message}`);
    } finally {
      setUploading(false);
    }
  };

  return (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-[60] p-4 pb-24">
      <div className="bg-slate-800 rounded-lg shadow-xl w-full max-w-4xl max-h-[calc(80vh-6rem)] flex flex-col">
        <div className="flex items-center justify-between p-6 border-b border-slate-700">
          <h2 className="text-2xl font-bold text-white">Upload New Track</h2>
          <button
            onClick={onClose}
            className="text-slate-400 hover:text-white transition-colors"
            disabled={uploading}
          >
            <X className="w-6 h-6" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="flex-1 overflow-y-auto p-6 space-y-6">
          <div className="bg-blue-900/20 border border-blue-700/30 rounded-lg p-4">
            <p className="text-sm text-blue-300">
              Upload an MP3 file and provide complete metadata. Duration is auto-detected. All fields help with search and organization.
            </p>
          </div>

          <div>
            <label className="block text-sm font-medium text-slate-300 mb-2">
              Audio File <span className="text-red-400">*</span>
            </label>
            <input
              type="file"
              accept="audio/mpeg,audio/mp3,.mp3"
              onChange={handleFileChange}
              disabled={uploading}
              className="w-full px-3 py-2 bg-slate-900 border border-slate-700 rounded-lg text-white file:mr-4 file:py-2 file:px-4 file:rounded-lg file:border-0 file:bg-blue-600 file:text-white file:cursor-pointer hover:file:bg-blue-700 disabled:opacity-50"
            />
            {audioFile && (
              <p className="mt-2 text-sm text-slate-400">
                Selected: {audioFile.name} ({(audioFile.size / 1024 / 1024).toFixed(2)} MB)
              </p>
            )}
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium text-slate-300 mb-2">
                Track ID
              </label>
              <input
                type="text"
                value={formData.track_id}
                onChange={(e) => handleInputChange('track_id', e.target.value)}
                placeholder="Auto-generated if empty"
                disabled={uploading}
                className="w-full px-3 py-2 bg-slate-900 border border-slate-700 rounded-lg text-white placeholder-slate-500 focus:ring-2 focus:ring-blue-500 focus:border-transparent disabled:opacity-50"
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-slate-300 mb-2">
                Track Name <span className="text-red-400">*</span>
              </label>
              <input
                type="text"
                value={formData.track_name}
                onChange={(e) => handleInputChange('track_name', e.target.value)}
                placeholder="Enter track name"
                disabled={uploading}
                required
                className="w-full px-3 py-2 bg-slate-900 border border-slate-700 rounded-lg text-white placeholder-slate-500 focus:ring-2 focus:ring-blue-500 focus:border-transparent disabled:opacity-50"
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-slate-300 mb-2">
                Artist Name
              </label>
              <input
                type="text"
                value={formData.artist_name}
                onChange={(e) => handleInputChange('artist_name', e.target.value)}
                placeholder="Enter artist name"
                disabled={uploading}
                className="w-full px-3 py-2 bg-slate-900 border border-slate-700 rounded-lg text-white placeholder-slate-500 focus:ring-2 focus:ring-blue-500 focus:border-transparent disabled:opacity-50"
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-slate-300 mb-2">
                Album Name
              </label>
              <input
                type="text"
                value={formData.album_name}
                onChange={(e) => handleInputChange('album_name', e.target.value)}
                placeholder="Enter album name"
                disabled={uploading}
                className="w-full px-3 py-2 bg-slate-900 border border-slate-700 rounded-lg text-white placeholder-slate-500 focus:ring-2 focus:ring-blue-500 focus:border-transparent disabled:opacity-50"
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-slate-300 mb-2">
                Genre Category
              </label>
              <input
                type="text"
                value={formData.genre_category}
                onChange={(e) => handleInputChange('genre_category', e.target.value)}
                placeholder="e.g., Classical Piano, Ambient"
                disabled={uploading}
                className="w-full px-3 py-2 bg-slate-900 border border-slate-700 rounded-lg text-white placeholder-slate-500 focus:ring-2 focus:ring-blue-500 focus:border-transparent disabled:opacity-50"
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-slate-300 mb-2">
                Energy Level
              </label>
              <select
                value={formData.energy_level}
                onChange={(e) => handleInputChange('energy_level', e.target.value)}
                disabled={uploading}
                className="w-full px-3 py-2 bg-slate-900 border border-slate-700 rounded-lg text-white focus:ring-2 focus:ring-blue-500 focus:border-transparent disabled:opacity-50"
              >
                <option value="low">Low</option>
                <option value="medium">Medium</option>
                <option value="high">High</option>
              </select>
            </div>

            <div>
              <label className="block text-sm font-medium text-slate-300 mb-2">
                Tempo
              </label>
              <input
                type="text"
                value={formData.tempo}
                onChange={(e) => handleInputChange('tempo', e.target.value)}
                placeholder="e.g., 120.00"
                disabled={uploading}
                className="w-full px-3 py-2 bg-slate-900 border border-slate-700 rounded-lg text-white placeholder-slate-500 focus:ring-2 focus:ring-blue-500 focus:border-transparent disabled:opacity-50"
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-slate-300 mb-2">
                BPM
              </label>
              <input
                type="text"
                value={formData.bpm}
                onChange={(e) => handleInputChange('bpm', e.target.value)}
                placeholder="e.g., 120"
                disabled={uploading}
                className="w-full px-3 py-2 bg-slate-900 border border-slate-700 rounded-lg text-white placeholder-slate-500 focus:ring-2 focus:ring-blue-500 focus:border-transparent disabled:opacity-50"
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-slate-300 mb-2">
                Duration (seconds) <span className="text-slate-500 text-xs font-normal">(auto-detected)</span>
              </label>
              <input
                type="text"
                value={formData.duration}
                onChange={(e) => handleInputChange('duration', e.target.value)}
                placeholder="Auto-detected from file"
                disabled={uploading}
                className="w-full px-3 py-2 bg-slate-900 border border-slate-700 rounded-lg text-white placeholder-slate-500 focus:ring-2 focus:ring-blue-500 focus:border-transparent disabled:opacity-50"
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-slate-300 mb-2">
                Source/Catalog
              </label>
              <input
                type="text"
                value={formData.source}
                onChange={(e) => handleInputChange('source', e.target.value)}
                placeholder="e.g., astropilot"
                disabled={uploading}
                className="w-full px-3 py-2 bg-slate-900 border border-slate-700 rounded-lg text-white placeholder-slate-500 focus:ring-2 focus:ring-blue-500 focus:border-transparent disabled:opacity-50"
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-slate-300 mb-2">
                File ID
              </label>
              <input
                type="text"
                value={formData.file_id}
                onChange={(e) => handleInputChange('file_id', e.target.value)}
                placeholder="Internal file identifier"
                disabled={uploading}
                className="w-full px-3 py-2 bg-slate-900 border border-slate-700 rounded-lg text-white placeholder-slate-500 focus:ring-2 focus:ring-blue-500 focus:border-transparent disabled:opacity-50"
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-slate-300 mb-2">
                Track Number
              </label>
              <input
                type="text"
                value={formData.track_number}
                onChange={(e) => handleInputChange('track_number', e.target.value)}
                placeholder="e.g., 1 or 01"
                disabled={uploading}
                className="w-full px-3 py-2 bg-slate-900 border border-slate-700 rounded-lg text-white placeholder-slate-500 focus:ring-2 focus:ring-blue-500 focus:border-transparent disabled:opacity-50"
              />
            </div>
          </div>

          <div>
            <div className="flex items-center justify-between mb-2">
              <label className="block text-sm font-medium text-slate-300">
                Assign to Channels {!skipChannelAssignment && <span className="text-red-400">*</span>}
              </label>
              <label className="flex items-center gap-2 cursor-pointer">
                <input
                  type="checkbox"
                  checked={skipChannelAssignment}
                  onChange={(e) => setSkipChannelAssignment(e.target.checked)}
                  disabled={uploading}
                  className="w-4 h-4 text-blue-600 bg-slate-800 border-slate-600 rounded focus:ring-blue-500 disabled:opacity-50"
                />
                <span className="text-sm text-slate-400">Skip for now</span>
              </label>
            </div>
            <div className="bg-slate-900 border border-slate-700 rounded-lg p-4 max-h-48 overflow-y-auto">
              {channels.length === 0 ? (
                <p className="text-slate-400 text-sm">No channels available</p>
              ) : (
                <div className="space-y-2">
                  {channels.map(channel => (
                    <label
                      key={channel.id}
                      className="flex items-center gap-3 p-2 hover:bg-slate-800 rounded cursor-pointer"
                    >
                      <input
                        type="checkbox"
                        checked={selectedChannels.includes(channel.id)}
                        onChange={() => toggleChannel(channel.id)}
                        disabled={uploading || skipChannelAssignment}
                        className="w-4 h-4 text-blue-600 bg-slate-800 border-slate-600 rounded focus:ring-blue-500 disabled:opacity-50"
                      />
                      <span className="text-white text-sm">
                        {channel.channel_number}. {channel.channel_name}
                      </span>
                    </label>
                  ))}
                </div>
              )}
            </div>
          </div>
        </form>

        <div className="flex items-center justify-end gap-3 p-6 border-t border-slate-700">
          <button
            type="button"
            onClick={onClose}
            disabled={uploading}
            className="px-6 py-2 bg-slate-700 hover:bg-slate-600 text-white rounded-lg transition-colors disabled:opacity-50"
          >
            Cancel
          </button>
          <button
            onClick={handleSubmit}
            disabled={uploading || !audioFile}
            className="px-6 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-lg transition-colors flex items-center gap-2 disabled:opacity-50 disabled:cursor-not-allowed"
          >
            {uploading ? (
              <>
                <Loader className="w-4 h-4 animate-spin" />
                Uploading...
              </>
            ) : (
              <>
                <Upload className="w-4 h-4" />
                Upload Track
              </>
            )}
          </button>
        </div>
      </div>
    </div>
  );
}
