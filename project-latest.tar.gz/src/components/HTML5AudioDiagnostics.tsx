import { Activity, Radio, Clock, Database, Signal, TrendingUp, Volume2, AlertCircle } from 'lucide-react';
import { AudioMetrics } from '../lib/html5AudioEngine';

interface HTML5AudioDiagnosticsProps {
  metrics: AudioMetrics;
}

export function HTML5AudioDiagnostics({ metrics }: HTML5AudioDiagnosticsProps) {
  const formatDuration = (ms: number): string => {
    if (ms === 0) return '0ms';
    if (ms < 1000) return `${Math.round(ms)}ms`;
    return `${(ms / 1000).toFixed(2)}s`;
  };

  const formatTime = (seconds: number): string => {
    if (!seconds || isNaN(seconds)) return '0:00';
    const mins = Math.floor(seconds / 60);
    const secs = Math.floor(seconds % 60);
    return `${mins}:${secs.toString().padStart(2, '0')}`;
  };

  const getStateColor = (state: string): string => {
    switch (state) {
      case 'playing': return 'text-green-600 bg-green-50';
      case 'loading': return 'text-yellow-600 bg-yellow-50';
      case 'ready': return 'text-blue-600 bg-blue-50';
      case 'paused': return 'text-orange-600 bg-orange-50';
      case 'stopped': return 'text-red-600 bg-red-50';
      default: return 'text-slate-600 bg-slate-50';
    }
  };

  const getBufferColor = (percentage: number): string => {
    if (percentage > 75) return 'bg-green-500';
    if (percentage > 50) return 'bg-yellow-500';
    if (percentage > 25) return 'bg-orange-500';
    return 'bg-red-500';
  };

  const getNetworkStateColor = (state: number): string => {
    switch (state) {
      case 1: return 'text-green-400'; // NETWORK_IDLE
      case 2: return 'text-yellow-400'; // NETWORK_LOADING
      case 3: return 'text-red-400'; // NETWORK_NO_SOURCE
      default: return 'text-slate-400'; // NETWORK_EMPTY
    }
  };

  const getReadyStateColor = (state: number): string => {
    if (state >= 4) return 'text-green-400';
    if (state >= 3) return 'text-blue-400';
    if (state >= 2) return 'text-yellow-400';
    if (state >= 1) return 'text-orange-400';
    return 'text-slate-400';
  };

  return (
    <div className="fixed bottom-24 left-0 right-0 bg-slate-900 text-slate-100 border-t border-b border-slate-700 font-mono text-xs z-40">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-3">
        <div className="flex items-center gap-1 mb-2">
          <Activity size={14} className="text-emerald-400" />
          <span className="font-bold text-emerald-400">HTML5 AUDIO DIAGNOSTICS</span>
          <span className="text-slate-500 ml-2">iOS-compatible audio monitoring</span>
        </div>

        {metrics.error && metrics.playbackState !== 'playing' && metrics.playbackState !== 'ready' && (
          <div className="mb-3 bg-red-900/30 border border-red-500 rounded p-2 flex items-center gap-2">
            <AlertCircle size={14} className="text-red-400 flex-shrink-0" />
            <span className="text-red-200 text-[10px]">{metrics.error}</span>
          </div>
        )}

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
          {/* Playback State */}
          <div className="bg-slate-800 rounded border border-slate-700 p-2">
            <div className="flex items-center gap-2 mb-1">
              <Radio size={12} className="text-blue-400" />
              <span className="text-slate-400 uppercase text-[10px]">Playback Status</span>
            </div>
            <div className="space-y-1">
              <div className="flex items-center gap-2">
                <span className={`px-2 py-0.5 rounded text-[10px] font-bold uppercase ${getStateColor(metrics.playbackState)}`}>
                  {metrics.playbackState}
                </span>
                {metrics.audioElement && (
                  <span className="text-slate-400 text-[10px]">
                    [{metrics.audioElement}]
                  </span>
                )}
              </div>
              {metrics.currentTrackId && (
                <div className="text-slate-400 text-[10px] truncate">
                  ID: {metrics.currentTrackId}
                </div>
              )}
              {(metrics.isWaiting || metrics.isStalled) && (
                <div className="flex items-center gap-1 text-yellow-400">
                  <div className="w-2 h-2 bg-yellow-400 rounded-full animate-pulse" />
                  <span className="text-[10px]">
                    {metrics.isWaiting ? 'Waiting for data' : 'Network stalled'}
                  </span>
                </div>
              )}
            </div>
          </div>

          {/* Network State */}
          <div className="bg-slate-800 rounded border border-slate-700 p-2">
            <div className="flex items-center gap-2 mb-1">
              <Signal size={12} className="text-cyan-400" />
              <span className="text-slate-400 uppercase text-[10px]">Network Status</span>
            </div>
            <div className="space-y-0.5">
              <div className="flex justify-between items-center">
                <span className="text-slate-500">Network:</span>
                <span className={`font-bold ${getNetworkStateColor(metrics.networkState)}`}>
                  {metrics.networkStateLabel}
                </span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-slate-500">Ready:</span>
                <span className={`font-bold ${getReadyStateColor(metrics.readyState)}`}>
                  {metrics.readyStateLabel}
                </span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-500">Can Play:</span>
                <span className={`font-bold ${metrics.canPlayThrough ? 'text-green-400' : 'text-red-400'}`}>
                  {metrics.canPlayThrough ? 'YES' : 'NO'}
                </span>
              </div>
            </div>
          </div>

          {/* Load Performance */}
          <div className="bg-slate-800 rounded border border-slate-700 p-2">
            <div className="flex items-center gap-2 mb-1">
              <Clock size={12} className="text-purple-400" />
              <span className="text-slate-400 uppercase text-[10px]">Load Performance</span>
            </div>
            <div className="space-y-0.5">
              <div className="flex justify-between">
                <span className="text-slate-500">Load Time:</span>
                <span className="text-white font-bold">{formatDuration(metrics.loadDuration)}</span>
              </div>
              {metrics.currentTrackUrl && (
                <div className="text-slate-400 text-[9px] truncate mt-1">
                  {metrics.currentTrackUrl}
                </div>
              )}
            </div>
          </div>

          {/* Buffer Info */}
          <div className="bg-slate-800 rounded border border-slate-700 p-2">
            <div className="flex items-center gap-2 mb-1">
              <Database size={12} className="text-cyan-400" />
              <span className="text-slate-400 uppercase text-[10px]">Buffer Status</span>
            </div>
            <div className="space-y-0.5">
              <div className="flex justify-between">
                <span className="text-slate-500">Buffered:</span>
                <span className="text-white font-bold">{formatTime(metrics.buffered)}</span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-slate-500">Progress:</span>
                <div className="flex items-center gap-2">
                  <div className="w-16 h-1.5 bg-slate-700 rounded overflow-hidden">
                    <div
                      className={`h-full transition-all ${getBufferColor(metrics.bufferPercentage)}`}
                      style={{ width: `${Math.min(metrics.bufferPercentage, 100)}%` }}
                    />
                  </div>
                  <span className="text-white font-bold w-8 text-right">
                    {Math.round(metrics.bufferPercentage)}%
                  </span>
                </div>
              </div>
            </div>
          </div>

          {/* Playback Position */}
          <div className="bg-slate-800 rounded border border-slate-700 p-2">
            <div className="flex items-center gap-2 mb-1">
              <TrendingUp size={12} className="text-green-400" />
              <span className="text-slate-400 uppercase text-[10px]">Playback Position</span>
            </div>
            <div className="space-y-0.5">
              <div className="flex justify-between">
                <span className="text-slate-500">Current:</span>
                <span className="text-white font-bold">{formatTime(metrics.currentTime)}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-500">Duration:</span>
                <span className="text-white font-bold">{formatTime(metrics.duration)}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-500">Remaining:</span>
                <span className="text-white font-bold">{formatTime(Math.max(0, metrics.duration - metrics.currentTime))}</span>
              </div>
            </div>
          </div>

          {/* System Info */}
          <div className="bg-slate-800 rounded border border-slate-700 p-2">
            <div className="flex items-center gap-2 mb-1">
              <Activity size={12} className="text-pink-400" />
              <span className="text-slate-400 uppercase text-[10px]">System Info</span>
            </div>
            <div className="space-y-0.5">
              <div className="flex justify-between">
                <span className="text-slate-500">Engine:</span>
                <span className="text-white font-bold">HTML5 Audio</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-500">Mode:</span>
                <span className="text-white font-bold">Crossfade</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-500">MediaSession:</span>
                <span className={`font-bold ${metrics.mediaSessionActive ? 'text-green-400' : 'text-red-400'}`}>
                  {metrics.mediaSessionActive ? 'ACTIVE' : 'INACTIVE'}
                </span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-500">Silent Switch:</span>
                <span className={`font-bold ${metrics.silentSwitchWorkaround ? 'text-green-400' : 'text-yellow-400'}`}>
                  {metrics.silentSwitchWorkaround ? 'COMPATIBLE' : 'STANDARD'}
                </span>
              </div>
            </div>
          </div>

          {/* Volume & Playback Rate */}
          <div className="bg-slate-800 rounded border border-slate-700 p-2">
            <div className="flex items-center gap-2 mb-1">
              <Volume2 size={12} className="text-yellow-400" />
              <span className="text-slate-400 uppercase text-[10px]">Audio Settings</span>
            </div>
            <div className="space-y-0.5">
              <div className="flex justify-between">
                <span className="text-slate-500">Volume:</span>
                <span className="text-white font-bold">{Math.round(metrics.volume * 100)}%</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-500">Muted:</span>
                <span className={`font-bold ${metrics.muted ? 'text-red-400' : 'text-green-400'}`}>
                  {metrics.muted ? 'YES' : 'NO'}
                </span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-500">Playback Rate:</span>
                <span className="text-white font-bold">{metrics.playbackRate.toFixed(2)}x</span>
              </div>
            </div>
          </div>
        </div>

        {/* Progress Bar */}
        {metrics.duration > 0 && (
          <div className="mt-3">
            <div className="w-full h-1 bg-slate-700 rounded overflow-hidden">
              <div
                className="h-full bg-gradient-to-r from-emerald-500 to-cyan-500 transition-all"
                style={{ width: `${(metrics.currentTime / metrics.duration) * 100}%` }}
              />
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
