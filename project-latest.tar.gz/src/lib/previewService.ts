import { supabase, AudioTrack } from './supabase';

export async function getPreviewTrack(
  channelId: string
): Promise<AudioTrack | null> {
  try {
    const { data, error } = await supabase
      .from('audio_tracks')
      .select('*')
      .eq('preview_channel_id', channelId)
      .eq('is_preview', true)
      .is('deleted_at', null)
      .maybeSingle();

    if (error) {
      console.error('Error fetching preview track:', error);
      return null;
    }

    return data;
  } catch (error) {
    console.error('Error in getPreviewTrack:', error);
    return null;
  }
}

export async function getPreviewTracks(
  channelIds: string[]
): Promise<Record<string, AudioTrack>> {
  try {
    console.log('Fetching preview tracks for channel IDs:', channelIds);

    const { data, error } = await supabase
      .from('audio_tracks')
      .select('*')
      .in('preview_channel_id', channelIds)
      .eq('is_preview', true)
      .is('deleted_at', null);

    if (error) {
      console.error('Error fetching preview tracks:', error);
      return {};
    }

    console.log('Preview tracks response:', data);

    const previewMap: Record<string, AudioTrack> = {};
    data?.forEach(track => {
      if (track.preview_channel_id) {
        previewMap[track.preview_channel_id] = track;
        console.log(`Mapped preview track for channel ${track.preview_channel_id}:`, track.metadata?.track_name);
      }
    });

    return previewMap;
  } catch (error) {
    console.error('Error in getPreviewTracks:', error);
    return {};
  }
}
